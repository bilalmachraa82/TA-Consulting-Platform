"use strict";(()=>{var e={};e.id=3435,e.ids=[3435],e.modules={53524:e=>{e.exports=require("@prisma/client")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},83511:(e,a,o)=>{o.r(a),o.d(a,{originalPathname:()=>R,patchFetch:()=>E,requestAsyncStorage:()=>T,routeModule:()=>f,serverHooks:()=>A,staticGenerationAsyncStorage:()=>I});var i={};o.r(i),o.d(i,{POST:()=>g});var r=o(49303),t=o(88716),s=o(60670),n=o(87070),d=o(75571),c=o(90455),l=o(71244),m=o(41620);let p={caracterizacao_empresa:{id:"caracterizacao_empresa",title:"Caracteriza\xe7\xe3o da Empresa",description:"Apresenta\xe7\xe3o do promotor: historial, capacidade t\xe9cnica e recursos",weight:10,maxTokens:1500,requiredContext:["empresa","documentos"],promptTemplate:`
Elabora a caracteriza\xe7\xe3o da empresa promotora para uma candidatura a fundos europeus.

EMPRESA:
- Nome: {{empresa_nome}}
- NIPC: {{empresa_nipc}}
- CAE: {{empresa_cae}}
- Setor: {{empresa_setor}}
- Dimens\xe3o: {{empresa_dimensao}}
- Regi\xe3o: {{empresa_regiao}}

ESTRUTURA OBRIGAT\xd3RIA:
1. Historial e Evolu\xe7\xe3o (breve)
2. Atividade Principal
3. Recursos Humanos (quantidade, qualifica\xe7\xf5es)
4. Capacidade T\xe9cnica e Tecnol\xf3gica
5. Posicionamento no Mercado
6. Principais Clientes/Mercados

INSTRU\xc7\xd5ES:
- Tom profissional e factual
- Destacar compet\xeancias relevantes para o projeto
- M\xe1ximo 1 p\xe1gina
`,suggestedStructure:["Historial","Atividade Principal","Recursos Humanos","Capacidade T\xe9cnica","Mercados"],validationHints:["Verificar se dados est\xe3o atualizados","Confirmar n\xba trabalhadores com IES","Validar CAE com certid\xe3o permanente"]},descricao_projeto:{id:"descricao_projeto",title:"Descri\xe7\xe3o do Projeto",description:"Vis\xe3o geral do investimento, enquadramento e objetivos",weight:15,maxTokens:2e3,requiredContext:["empresa","aviso","historico"],promptTemplate:`
Escreve a descri\xe7\xe3o do projeto para a candidatura ao {{aviso_nome}}.

CONTEXTO:
- Empresa: {{empresa_nome}}
- Setor: {{empresa_setor}}
- Investimento previsto: {{investimento_total}}€

ESTRUTURA OBRIGAT\xd3RIA:
1. Enquadramento Estrat\xe9gico
   - Porqu\xea este projeto agora?
   - Como se alinha com a estrat\xe9gia da empresa?
   
2. Descri\xe7\xe3o do Investimento
   - O que vai ser feito concretamente?
   - Que equipamentos/tecnologias ser\xe3o adquiridos?
   
3. Objetivos Principais
   - Objetivos quantitativos (vendas, emprego, exporta\xe7\xf5es)
   - Objetivos qualitativos (competitividade, inova\xe7\xe3o)
   
4. Resultados Esperados
   - Impacto no neg\xf3cio
   - Prazo de implementa\xe7\xe3o

INSTRU\xc7\xd5ES:
- Alinhar com crit\xe9rios espec\xedficos do aviso
- Usar linguagem t\xe9cnica mas acess\xedvel
- Ser espec\xedfico e quantitativo quando poss\xedvel
`,suggestedStructure:["Enquadramento Estrat\xe9gico","Descri\xe7\xe3o do Investimento","Objetivos do Projeto","Resultados Esperados"],validationHints:["Verificar alinhamento com crit\xe9rios do aviso","Confirmar valores de investimento","Validar objetivos s\xe3o realistas"]},componente_inovacao:{id:"componente_inovacao",title:"Componente de Inova\xe7\xe3o",description:"Descri\xe7\xe3o do car\xe1cter inovador e diferenciador do projeto",weight:20,maxTokens:2e3,requiredContext:["empresa","aviso","rag_candidaturas"],promptTemplate:`
Descreve a componente de inova\xe7\xe3o do projeto para candidatura a fundos.

CONTEXTO:
- Projeto: {{projeto_nome}}
- Tipo de inova\xe7\xe3o pretendida: {{projeto_tipo_inovacao}}

ESTRUTURA OBRIGAT\xd3RIA:
1. Natureza da Inova\xe7\xe3o
   - Produto novo ou melhorado?
   - Processo novo ou melhorado?
   - Inova\xe7\xe3o organizacional?
   
2. Estado da Arte
   - O que existe atualmente no mercado?
   - Quais s\xe3o as limita\xe7\xf5es das solu\xe7\xf5es atuais?
   
3. Proposta Inovadora
   - Em que consiste a inova\xe7\xe3o?
   - Qual o car\xe1cter diferenciador?
   
4. Vantagem Competitiva
   - Que benef\xedcios traz vs concorr\xeancia?
   - \xc9 replic\xe1vel ou defens\xe1vel?
   
5. Propriedade Intelectual (se aplic\xe1vel)
   - Patentes existentes ou a registar
   - Segredos industriais

INSTRU\xc7\xd5ES:
- Fundamentar com dados/estudos quando poss\xedvel
- Comparar com concorr\xeancia/alternativas
- Evitar generalidades - ser espec\xedfico
`,suggestedStructure:["Natureza da Inova\xe7\xe3o","Estado da Arte","Proposta Diferenciadora","Vantagem Competitiva"],validationHints:["Verificar se inova\xe7\xe3o \xe9 real ou incremental","Confirmar n\xe3o existe igual no mercado","Validar dados de concorr\xeancia"]},analise_mercado:{id:"analise_mercado",title:"An\xe1lise de Mercado",description:"An\xe1lise do mercado-alvo, dimens\xe3o e estrat\xe9gia comercial",weight:15,maxTokens:1800,requiredContext:["empresa","documentos"],promptTemplate:`
Elabora a an\xe1lise de mercado para o projeto.

CONTEXTO:
- Setor: {{empresa_setor}}
- Mercados atuais: {{empresa_mercados}}

ESTRUTURA OBRIGAT\xd3RIA:
1. Caracteriza\xe7\xe3o do Mercado
   - Dimens\xe3o (volume, valor)
   - Tend\xeancias de crescimento
   - Principais players
   
2. Mercado-Alvo
   - Segmentos target
   - Perfil de cliente
   - Geografia (nacional/exporta\xe7\xe3o)
   
3. An\xe1lise Competitiva
   - Principais concorrentes
   - Posicionamento relativo
   - Vantagens competitivas
   
4. Estrat\xe9gia de Entrada/Crescimento
   - Canais de distribui\xe7\xe3o
   - Pricing
   - Plano de marketing

INSTRU\xc7\xd5ES:
- Incluir dados quantitativos (fontes: INE, Eurostat, estudos setor)
- Ser realista nas proje\xe7\xf5es
- Identificar riscos e como mitigar
`,suggestedStructure:["Dimens\xe3o do Mercado","Segmentos Target","An\xe1lise Competitiva","Estrat\xe9gia Comercial"],validationHints:["Verificar fontes dos dados","Confirmar proje\xe7\xf5es s\xe3o realistas","Validar conhecimento do mercado"]},equipa_tecnica:{id:"equipa_tecnica",title:"Equipa T\xe9cnica",description:"Apresenta\xe7\xe3o da equipa respons\xe1vel pelo projeto",weight:10,maxTokens:1500,requiredContext:["empresa","documentos"],promptTemplate:`
Descreve a equipa t\xe9cnica respons\xe1vel pela execu\xe7\xe3o do projeto.

ESTRUTURA OBRIGAT\xd3RIA:
1. Coordenador/Respons\xe1vel do Projeto
   - Nome e fun\xe7\xe3o
   - Qualifica\xe7\xf5es
   - Experi\xeancia relevante
   
2. Equipa T\xe9cnica
   - Perfis e compet\xeancias
   - Dedica\xe7\xe3o ao projeto (%)
   
3. Recursos a Contratar (se aplic\xe1vel)
   - Perfis necess\xe1rios
   - Justifica\xe7\xe3o

INSTRU\xc7\xd5ES:
- Destacar experi\xeancia relevante para o projeto
- Incluir forma\xe7\xe3o acad\xe9mica e profissional
- Quantificar dedica\xe7\xe3o (horas/m\xeas ou %)
`,suggestedStructure:["Coordenador do Projeto","Equipa T\xe9cnica Existente","Contrata\xe7\xf5es Previstas"],validationHints:["Confirmar pessoas existem na empresa","Verificar CVs est\xe3o atualizados","Validar disponibilidade real"]},plano_trabalhos:{id:"plano_trabalhos",title:"Plano de Trabalhos e Cronograma",description:"Estrutura temporal da execu\xe7\xe3o do projeto",weight:10,maxTokens:1500,requiredContext:["aviso"],promptTemplate:`
Elabora o plano de trabalhos para execu\xe7\xe3o do projeto em {{duracao_meses}} meses.

ESTRUTURA OBRIGAT\xd3RIA:
1. Fases/Etapas do Projeto
   Para cada fase:
   - Designa\xe7\xe3o
   - Dura\xe7\xe3o (m\xeas in\xedcio - m\xeas fim)
   - Atividades principais
   - Deliverables/Outputs
   - Respons\xe1vel

2. Marcos Principais (Milestones)
   - M\xeas X: [Marco]

3. Depend\xeancias
   - Que fases dependem de outras?

FORMATO SUGERIDO:
Fase 1: [Nome] (M1-M3)
- Atividade 1.1: ...
- Atividade 1.2: ...
- Output: ...

INSTRU\xc7\xd5ES:
- Ser realista nos prazos
- Incluir todas as atividades eleg\xedveis
- Considerar lead times de aquisi\xe7\xf5es
`,suggestedStructure:["Fase 1: Prepara\xe7\xe3o","Fase 2: Aquisi\xe7\xe3o","Fase 3: Implementa\xe7\xe3o","Fase 4: Testes","Fase 5: Comercializa\xe7\xe3o"],validationHints:["Verificar se prazos s\xe3o realistas","Confirmar alinhamento com elegibilidade","Validar depend\xeancias fazem sentido"]},objetivos_smart:{id:"objetivos_smart",title:"Objetivos e Metas (SMART)",description:"Defini\xe7\xe3o quantitativa dos objetivos do projeto",weight:10,maxTokens:1200,requiredContext:["empresa","aviso"],promptTemplate:`
Define objetivos SMART para o projeto.

SMART = Espec\xedfico, Mensur\xe1vel, Ating\xedvel, Relevante, Temporal

ESTRUTURA OBRIGAT\xd3RIA:
Para cada objetivo (3-5 no total):
- Objetivo: [Descri\xe7\xe3o]
- Indicador/M\xe9trica: [Como medir]
- Meta: [Valor quantitativo]
- Prazo: [Quando atingir]
- Baseline: [Valor atual]

EXEMPLO:
Objetivo: Aumentar volume de exporta\xe7\xf5es
Indicador: % do VN proveniente de exporta\xe7\xf5es
Baseline: 15%
Meta: 30%
Prazo: 24 meses ap\xf3s conclus\xe3o do projeto

INSTRU\xc7\xd5ES:
- Alinhar com crit\xe9rios de m\xe9rito do aviso
- Ser ambicioso mas realista
- Incluir m\xe9tricas de emprego, VN, exporta\xe7\xf5es
`,suggestedStructure:["Objetivos de Crescimento","Objetivos de Emprego","Objetivos de Internacionaliza\xe7\xe3o","Objetivos de Inova\xe7\xe3o"],validationHints:["Verificar baseline est\xe1 correto","Confirmar metas s\xe3o ating\xedveis","Validar alinhamento com crit\xe9rios"]},investimento_orcamento:{id:"investimento_orcamento",title:"Investimento e Or\xe7amento",description:"Detalhamento do investimento por rubricas eleg\xedveis",weight:10,maxTokens:1500,requiredContext:["aviso","documentos"],promptTemplate:`
Estrutura o plano de investimentos do projeto.

INVESTIMENTO TOTAL: {{investimento_total}}€

RUBRICAS T\xcdPICAS (adaptar ao aviso):
1. Constru\xe7\xe3o/Obras
2. Equipamento Produtivo
3. Equipamento Administrativo
4. Software e Licen\xe7as
5. Propriedade Industrial
6. Servi\xe7os de Consultoria
7. Outras despesas eleg\xedveis

PARA CADA RUBRICA:
- Designa\xe7\xe3o
- Valor (€)
- Justifica\xe7\xe3o/Necessidade

INSTRU\xc7\xd5ES:
- Verificar elegibilidade de cada rubrica no aviso
- Incluir apenas despesas diretamente relacionadas
- Ter or\xe7amentos de suporte quando poss\xedvel
`,suggestedStructure:["Investimentos Corp\xf3reos","Investimentos Incorp\xf3reos","Despesas de Funcionamento","Resumo por Rubrica"],validationHints:["Confirmar rubricas s\xe3o eleg\xedveis","Verificar or\xe7amentos de suporte","Validar razoabilidade dos valores"]},analise_financeira:{id:"analise_financeira",title:"An\xe1lise Financeira",description:"Viabilidade econ\xf3mico-financeira do projeto (TIR, VAL, Payback)",weight:15,maxTokens:1500,requiredContext:["empresa","documentos"],promptTemplate:`
Elabora a an\xe1lise de viabilidade financeira do projeto.

INVESTIMENTO: {{investimento_total}}€
INCENTIVO ESPERADO: {{incentivo_esperado}}€

INDICADORES OBRIGAT\xd3RIOS:
1. VAL (Valor Atual L\xedquido)
   - Taxa de desconto utilizada
   - Valor calculado
   - Interpreta\xe7\xe3o

2. TIR (Taxa Interna de Rentabilidade)
   - Valor calculado
   - Compara\xe7\xe3o com custo de capital

3. Payback Period
   - Per\xedodo de recupera\xe7\xe3o do investimento

4. Proje\xe7\xf5es Financeiras (5 anos)
   - Volume de Neg\xf3cios
   - EBITDA
   - Resultado L\xedquido

5. Fontes de Financiamento
   - Incentivo n\xe3o reembols\xe1vel
   - Capitais pr\xf3prios
   - Financiamento banc\xe1rio (se aplic\xe1vel)

INSTRU\xc7\xd5ES:
- Ser conservador nas proje\xe7\xf5es
- Justificar pressupostos
- Incluir an\xe1lise de sensibilidade se relevante
`,suggestedStructure:["Pressupostos","Proje\xe7\xf5es de Receitas","Proje\xe7\xf5es de Custos","Indicadores (VAL, TIR, Payback)","Fontes de Financiamento"],validationHints:["Verificar c\xe1lculos de VAL/TIR","Confirmar pressupostos s\xe3o realistas","Validar capacidade de capitais pr\xf3prios"]},sustentabilidade:{id:"sustentabilidade",title:"Impacto e Sustentabilidade",description:"Contributo para sustentabilidade e princ\xedpios DNSH",weight:10,maxTokens:1200,requiredContext:["empresa","aviso"],promptTemplate:`
Descreve o contributo do projeto para a sustentabilidade.

PRINC\xcdPIOS DNSH (Do No Significant Harm):
O projeto n\xe3o pode prejudicar significativamente:
1. Mitiga\xe7\xe3o das altera\xe7\xf5es clim\xe1ticas
2. Adapta\xe7\xe3o \xe0s altera\xe7\xf5es clim\xe1ticas
3. Utiliza\xe7\xe3o sustent\xe1vel da \xe1gua
4. Economia circular
5. Preven\xe7\xe3o e controlo da polui\xe7\xe3o
6. Biodiversidade e ecossistemas

ESTRUTURA OBRIGAT\xd3RIA:
1. Contributo Ambiental
   - Efici\xeancia energ\xe9tica
   - Redu\xe7\xe3o de emiss\xf5es
   - Economia circular
   
2. Contributo Social
   - Cria\xe7\xe3o de emprego
   - Igualdade de g\xe9nero
   - Inclus\xe3o
   
3. Contributo Econ\xf3mico
   - Competitividade regional
   - Cadeia de valor

4. Declara\xe7\xe3o DNSH
   - Confirmar cumprimento dos 6 princ\xedpios

INSTRU\xc7\xd5ES:
- Ser espec\xedfico sobre impactos positivos
- Quantificar quando poss\xedvel (kWh poupados, emiss\xf5es evitadas)
- N\xe3o fazer claims sem fundamento
`,suggestedStructure:["Impacto Ambiental","Impacto Social","Impacto Econ\xf3mico","Conformidade DNSH"],validationHints:["Verificar claims s\xe3o fundamentados","Confirmar cumprimento DNSH","Validar m\xe9tricas ambientais"]},estado_arte:{id:"estado_arte",title:"Estado da Arte",description:"An\xe1lise do conhecimento e tecnologia existente (para I&D)",weight:15,maxTokens:2e3,requiredContext:["aviso","rag_candidaturas"],promptTemplate:`
Elabora o estado da arte para o projeto de I&D.

ESTRUTURA OBRIGAT\xd3RIA:
1. Revis\xe3o Bibliogr\xe1fica
   - Principais publica\xe7\xf5es/estudos na \xe1rea
   - Tend\xeancias tecnol\xf3gicas
   
2. Solu\xe7\xf5es Existentes
   - O que existe no mercado?
   - Quais as limita\xe7\xf5es?
   
3. Benchmarking Tecnol\xf3gico
   - Tecnologias concorrentes
   - Compara\xe7\xe3o de caracter\xedsticas
   
4. Gaps Identificados
   - O que falta no estado atual?
   - Que problema pretendemos resolver?
   
5. Contributo do Projeto
   - Como avan\xe7a o conhecimento?
   - Que novidade traz?

INSTRU\xc7\xd5ES:
- Citar fontes (artigos, patentes, estudos)
- Ser objetivo na an\xe1lise
- Demonstrar conhecimento profundo da \xe1rea
`,suggestedStructure:["Revis\xe3o da Literatura","Tecnologias Existentes","Gaps e Oportunidades","Contributo Cient\xedfico"],validationHints:["Verificar fontes bibliogr\xe1ficas","Confirmar gaps s\xe3o reais","Validar contributo \xe9 original"]},diagnostico_digital:{id:"diagnostico_digital",title:"Diagn\xf3stico de Maturidade Digital",description:"Avalia\xe7\xe3o do estado atual de digitaliza\xe7\xe3o (para PRR)",weight:20,maxTokens:1500,requiredContext:["empresa","documentos"],promptTemplate:`
Elabora o diagn\xf3stico de maturidade digital da empresa.

DIMENS\xd5ES A AVALIAR:
1. Infraestrutura Tecnol\xf3gica
   - Hardware/Rede
   - Cloud
   - Ciberseguran\xe7a
   
2. Sistemas de Informa\xe7\xe3o
   - ERP
   - CRM
   - Business Intelligence
   
3. Processos Digitais
   - % processos digitalizados
   - Automa\xe7\xe3o
   
4. Compet\xeancias Digitais
   - N\xedvel da equipa
   - Forma\xe7\xe3o existente
   
5. Presen\xe7a Digital
   - Website
   - E-commerce
   - Redes sociais

SCORE DE MATURIDADE (1-5 por dimens\xe3o):
1 = Inexistente
2 = B\xe1sico
3 = Interm\xe9dio
4 = Avan\xe7ado
5 = Otimizado

INSTRU\xc7\xd5ES:
- Ser honesto na autoavalia\xe7\xe3o
- Identificar gaps priorit\xe1rios
- Fundamentar com evid\xeancias
`,suggestedStructure:["Infraestrutura Atual","Sistemas e Processos","Compet\xeancias","Score de Maturidade","Gaps Priorit\xe1rios"],validationHints:["Verificar score \xe9 realista","Confirmar gaps identificados","Validar com evid\xeancias"]},plano_digitalizacao:{id:"plano_digitalizacao",title:"Plano de Digitaliza\xe7\xe3o",description:"Estrat\xe9gia e a\xe7\xf5es de transforma\xe7\xe3o digital (para PRR)",weight:30,maxTokens:2e3,requiredContext:["empresa","aviso"],promptTemplate:`
Elabora o plano de digitaliza\xe7\xe3o para o projeto PRR.

ESTRUTURA OBRIGAT\xd3RIA:
1. Objetivos de Digitaliza\xe7\xe3o
   - Onde queremos estar em 2 anos?
   - Que n\xedvel de maturidade pretendemos?
   
2. A\xe7\xf5es de Transforma\xe7\xe3o
   Para cada a\xe7\xe3o:
   - Descri\xe7\xe3o
   - Tecnologia a implementar
   - Investimento
   - Prazo
   
3. Tecnologias a Implementar
   - Nome/tipo
   - Fornecedor (se conhecido)
   - Justifica\xe7\xe3o
   
4. KPIs de Sucesso
   - Como medir o sucesso?
   - Metas quantitativas
   
5. Riscos e Mitiga\xe7\xe3o
   - Principais riscos
   - Plano de mitiga\xe7\xe3o

INSTRU\xc7\xd5ES:
- Ser espec\xedfico nas tecnologias
- Alinhar com diagn\xf3stico (resolver gaps)
- Incluir forma\xe7\xe3o se necess\xe1rio
`,suggestedStructure:["Vis\xe3o Digital","A\xe7\xf5es Priorit\xe1rias","Roadmap de Implementa\xe7\xe3o","KPIs","Gest\xe3o de Riscos"],validationHints:["Verificar alinha com diagn\xf3stico","Confirmar tecnologias s\xe3o eleg\xedveis","Validar cronograma \xe9 realista"]}},u=(p.caracterizacao_empresa,p.descricao_projeto,p.componente_inovacao,p.analise_mercado,p.objetivos_smart,p.plano_trabalhos,p.investimento_orcamento,p.sustentabilidade,p.caracterizacao_empresa,p.estado_arte,p.descricao_projeto,p.componente_inovacao,p.equipa_tecnica,p.plano_trabalhos,p.objetivos_smart,p.analise_financeira,p.sustentabilidade,p.caracterizacao_empresa,p.diagnostico_digital,p.plano_digitalizacao,p.investimento_orcamento,p.caracterizacao_empresa,p.diagnostico_digital,p.plano_digitalizacao,p.objetivos_smart,p.plano_trabalhos,p.investimento_orcamento,p.sustentabilidade,Object.values(p));class x{async generateSectionStream(e,a,o=!1){if(!m.qb)throw Error("OpenRouter client not configured.");let i=u.find(a=>a.id===e);if(!i)throw Error(`Section ${e} not found`);let r=o?m.jd["claude-opus-4-5"]:m.jd["claude-4-5-sonnet"],t=this.buildPrompt(i,a),s=await m.qb.chat.completions.create({model:r.id,messages:[{role:"system",content:m.s6+"\n\nCRITICAL: You must cite your sources using the format [ID: XX] whenever you use information from the provided Aviso Chunks. This is essential for transparency."},{role:"user",content:t}],stream:!0,temperature:.7,max_tokens:i.maxTokens||2e3});return new ReadableStream({async start(e){let a=new TextEncoder;try{for await(let o of s){let i=o.choices[0]?.delta?.content||"";i&&e.enqueue(a.encode(i))}}catch(a){e.error(a)}finally{e.close()}}})}buildPrompt(e,a){let o=e.promptTemplate;if(o=(o=(o=(o=(o=o.replace("{{aviso_nome}}",a.aviso?.nome||"Aviso PT2030")).replace("{{empresa_nome}}",a.empresa?.nome||"Empresa")).replace("{{empresa_setor}}",a.empresa?.setor||"Geral")).replace("{{investimento_total}}","150.000")).replace("{{duracao_meses}}","18"),a.chunks&&a.chunks.length>0){let e=a.chunks.map(e=>`[ID: ${e.id}] ${e.content}`).join("\n\n");o+=`

--- CONTEXTO DO AVISO (REGRAS OFICIAIS) ---
Usa estes IDs para cita\xe7\xf5es:
${e}
--- FIM DO CONTEXTO DO AVISO ---`}return a.docsContext&&(o+=`

--- CONTEXTO DA EMPRESA (MEM\xd3RIA DESCRITIVA / DADOS) ---
${a.docsContext}
--- FIM DO CONTEXTO DA EMPRESA ---`),a.userInstructions&&(o+=`

Instru\xe7\xf5es adicionais do utilizador: ${a.userInstructions}`),o+="\n\nIMPORTANTE: Escreve de forma profissional, em PT-PT, e fundamenta sempre as tuas afirma\xe7\xf5es com os dados do aviso usando [ID: XX]."}calculateConfidence(e,a){return e.length<100?"low":e.includes("[")&&e.includes("]")?"medium":"high"}}let v=new x;async function g(e){try{let a=await (0,d.getServerSession)(c.L);if(!a?.user?.email)return new n.NextResponse("Unauthorized",{status:401});let{sectionId:o,empresaId:i,avisoId:r,userInstructions:t,useOpus:s}=await e.json();if(!o||!i||!r)return new n.NextResponse("Missing required fields",{status:400});let m=await l._B.empresa.findUnique({where:{id:i},include:{documentos:!0}}),p=await l._B.aviso.findUnique({where:{id:r},include:{chunks:{take:20}}});if(!m||!p)return new n.NextResponse("Resource not found",{status:404});let u=await v.generateSectionStream(o,{empresa:m,aviso:p,chunks:p.chunks,docsContext:m.documentos&&m.documentos.length>0?`A empresa tem ${m.documentos.length} documentos anexados. Foca no hist\xf3rico de inova\xe7\xe3o mencionado.`:void 0,userInstructions:t},!!s);return new Response(u,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}catch(e){return console.error("Writer API Error:",e),new n.NextResponse("Internal AI Error",{status:500})}}let f=new r.AppRouteRouteModule({definition:{kind:t.x.APP_ROUTE,page:"/api/writer/candidatura/route",pathname:"/api/writer/candidatura",filename:"route",bundlePath:"app/api/writer/candidatura/route"},resolvedPagePath:"/Users/bilal/Programaçao/TA consulting pltaform ai/TA-Consulting-Platform/app/api/writer/candidatura/route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:T,staticGenerationAsyncStorage:I,serverHooks:A}=f,R="/api/writer/candidatura/route";function E(){return(0,s.patchFetch)({serverHooks:A,staticGenerationAsyncStorage:I})}},90455:(e,a,o)=>{o.d(a,{L:()=>d});var i=o(13539),r=o(53797),t=o(42023),s=o.n(t),n=o(71244);let d={adapter:(()=>{try{return(0,i.N)(n._B)}catch{return}})(),session:{strategy:"jwt"},pages:{signIn:"/auth/login"},providers:[(0,r.Z)({name:"credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;let a=await n._B.user.findUnique({where:{email:e.email}});return a&&a.password&&await s().compare(e.password,a.password)?{id:a.id,email:a.email,name:a.name,role:a.role}:null}})],callbacks:{jwt:async({token:e,user:a})=>(a&&(e.role=a.role),e),session:async({session:e,token:a})=>(a&&e.user&&(e.user.id=a.sub,e.user.role=a.role),e)}}},41620:(e,a,o)=>{o.d(a,{jd:()=>s,qb:()=>t,s6:()=>n});var i=o(91088);let r=process.env.OPENROUTER_API_KEY;r||console.warn("⚠️ OPENROUTER_API_KEY not set");let t=r?new i.ZP({apiKey:r,baseURL:"https://openrouter.ai/api/v1",defaultHeaders:{"HTTP-Referer":process.env.NEXTAUTH_URL||"http://localhost:3000","X-Title":"TA Consulting Platform"}}):null,s={"llama-3-3-70b":{id:"meta-llama/llama-3.3-70b-instruct:free",name:"LLaMA 3.3 70B",provider:"Meta",description:"Master Storyteller. Excelente para narrativas longas e di\xe1logos. Top 5 LMArena Open-Source.",tier:"free",premium:!1,recommended:!0},"qwen-2-5-72b":{id:"qwen/qwen-2.5-72b-instruct:free",name:"Qwen 2.5 72B",provider:"Alibaba",description:"Precis\xe3o t\xe9cnica superior. Ideal para mem\xf3rias descritivas e textos formais.",tier:"free",premium:!1,recommended:!0},"deepseek-r1":{id:"deepseek/deepseek-r1:free",name:"DeepSeek R1",provider:"DeepSeek",description:"Racioc\xednio par com GPT-4. Open-source, gratuito, excelente para an\xe1lises.",tier:"free",premium:!1,recommended:!1},"gemma-3-27b":{id:"google/gemma-3-27b-it:free",name:"Gemma 3 27B",provider:"Google",description:"Brainstorming Buddy. R\xe1pido para ideias e esbo\xe7os iniciais.",tier:"free",premium:!1,recommended:!1},"mistral-small":{id:"mistralai/mistral-small:free",name:"Mistral Small",provider:"Mistral AI",description:"Leve e r\xe1pido. Bom para rascunhos r\xe1pidos e itera\xe7\xf5es.",tier:"free",premium:!1,recommended:!1},"claude-4-5-sonnet":{id:"anthropic/claude-sonnet-4",name:"Claude Sonnet 4",provider:"Anthropic",description:"O workhorse para Mem\xf3rias Descritivas. Equil\xedbrio perfeito qualidade/custo. (AoT Dec 2025)",tier:"paid",premium:!1,recommended:!0},"claude-opus-4-5":{id:"anthropic/claude-opus-4",name:"Claude Opus 4",provider:"Anthropic",description:"Coding benchmark #1 mundial. Para sec\xe7\xf5es cr\xedticas e workflows agentic. (AoT Dec 2025)",tier:"paid",premium:!0,recommended:!1},"mistral-large-3":{id:"mistralai/mistral-large-2512",name:"Mistral Large 3",provider:"Mistral AI",description:"Dezembro 2025. 675B MoE. Especialista em normas Europeias, Apache 2.0. (AoT Dec 2025)",tier:"paid",premium:!1,recommended:!1},"gpt-4o":{id:"openai/gpt-4o",name:"GPT-4o",provider:"OpenAI",description:"Multimodal, r\xe1pido. Bom para tarefas mistas texto+an\xe1lise.",tier:"paid",premium:!0,recommended:!1}};Object.entries(s).filter(([e,a])=>"free"===a.tier).map(([e])=>e),Object.entries(s).filter(([e,a])=>"paid"===a.tier).map(([e])=>e),Object.entries(s).filter(([e,a])=>a.recommended).map(([e])=>e);let n=`\xc9s um consultor s\xe9nior especialista em fundos europeus (Portugal 2030), treinado com os standards do Project AM\xc1LIA.
A tua miss\xe3o \xe9 produzir documenta\xe7\xe3o t\xe9cnica de elite para candidaturas a financiamento p\xfablico.

DIRETIVAS LINGU\xcdSTICAS ABSOLUTAS (PT-PT):
1. Apenas Portugu\xeas Europeu de norma culta. Toler\xe2ncia zero para brasileirismos.
   - ERRADO: "Equipe", "Usu\xe1rio", "Tela", "Planejamento", "Registro", "A\xe7\xe3o".
   - CORRETO: "Equipa", "Utilizador", "Ecr\xe3", "Planeamento", "Registo", "Ac\xe3o".
2. Sintaxe: Usa a constru\xe7\xe3o "a fazer" (infinitivo gerundivo) preferencialmente ao ger\xfandio ("fazendo"), salvo se natural.
3. Tom: Institucional, s\xf3brio, anal\xedtico e orientado a m\xe9tricas. Evita adjetiva\xe7\xe3o vazia ("inovador", "disruptivo") sem substancia\xe7\xe3o.

ESTRUTURA:
- Responde com densidade de informa\xe7\xe3o.
- Privilegia listas estruturadas e dados quantitativos.
- Nunca uses "Ol\xe1" ou "Aqui est\xe1". Entrega apenas o conte\xfado.`}};var a=require("../../../../webpack-runtime.js");a.C(e);var o=e=>a(a.s=e),i=a.X(0,[9276,2776,5972,9637,1088,1244],()=>o(83511));module.exports=i})();