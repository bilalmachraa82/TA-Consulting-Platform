(()=>{var e={};e.id=2748,e.ids=[2748],e.modules={62688:e=>{function t(e){return Promise.resolve().then(()=>{var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t})}t.keys=()=>[],t.resolve=t,t.id=62688,e.exports=t},53524:e=>{"use strict";e.exports=require("@prisma/client")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{"use strict";e.exports=require("assert")},78893:e=>{"use strict";e.exports=require("buffer")},61282:e=>{"use strict";e.exports=require("child_process")},84770:e=>{"use strict";e.exports=require("crypto")},17702:e=>{"use strict";e.exports=require("events")},92048:e=>{"use strict";e.exports=require("fs")},32615:e=>{"use strict";e.exports=require("http")},32694:e=>{"use strict";e.exports=require("http2")},35240:e=>{"use strict";e.exports=require("https")},19801:e=>{"use strict";e.exports=require("os")},55315:e=>{"use strict";e.exports=require("path")},86624:e=>{"use strict";e.exports=require("querystring")},76162:e=>{"use strict";e.exports=require("stream")},74175:e=>{"use strict";e.exports=require("tty")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},30694:(e,t,r)=>{"use strict";r.r(t),r.d(t,{originalPathname:()=>E,patchFetch:()=>R,requestAsyncStorage:()=>h,routeModule:()=>A,serverHooks:()=>P,staticGenerationAsyncStorage:()=>T});var a={};r.r(a),r.d(a,{GET:()=>f,POST:()=>v});var o=r(49303),i=r(88716),s=r(60670),n=r(87070),c=r(75571),d=r(90455),p=r(13275),l=r(71244),u=r(41620),m=r(21369);let x=process.env.GEMINI_CANDIDATURAS_STORE_ID;async function g(e,t,r,a=3){let o=Date.now();if(!x)return console.warn("[RAG] GEMINI_CANDIDATURAS_STORE_ID n\xe3o configurado"),{examples:[],citationCount:0,model:"none",latencyMs:0};let i=`Procura exemplos de como escrever a sec\xe7\xe3o "${e}" em candidaturas aprovadas.

DESCRI\xc7\xc3O DA SEC\xc7\xc3O: ${t}

${r?`PROGRAMA: ${r.toUpperCase().replace(/-/g," ")}`:""}

TAREFA: Extrai at\xe9 ${a} exemplos reais de candidaturas aprovadas que mostrem como esta sec\xe7\xe3o foi escrita com sucesso.

Para cada exemplo, indica:
1. O texto da sec\xe7\xe3o (resumido se muito longo)
2. O programa/aviso de onde vem
3. Porque \xe9 um bom exemplo

Responde em formato estruturado.`;try{let t=await (0,m.u)({model:m.Rn,prompt:i,storeName:x,temperature:0,maxOutputTokens:2048}),r=Date.now()-o,s=function(e,t){let r=[];for(let a of e.citations.citedSources.slice(0,t))r.push({content:e.text.slice(0,500),source:a.title||a.source||"Candidatura Hist\xf3rica",score:.9});if(0===r.length&&e.text.length>100)for(let a of e.text.split(/(?:^|\n)(?:\d+\.|Exemplo \d+:)/i).slice(1,t+1))a.trim().length>50&&r.push({content:a.trim().slice(0,500),source:"Candidatura Hist\xf3rica",score:.7});return r}(t,a);return console.log(`[RAG] Encontrados ${s.length} exemplos para "${e}" em ${r}ms`),{examples:s,citationCount:t.citations.citationCount,model:m.Rn,latencyMs:r}}catch(e){return console.error("[RAG] Erro ao buscar exemplos:",e.message),{examples:[],citationCount:0,model:m.Rn,latencyMs:Date.now()-o}}}async function v(e){try{let t=await (0,c.getServerSession)(d.L);if(!t?.user?.email)return n.NextResponse.json({error:"Autentica\xe7\xe3o necess\xe1ria"},{status:401});let a=await l._B.user.findUnique({where:{email:t.user.email},select:{id:!0,plan:!0}}),{canAccessFeature:o}=await Promise.all([r.e(4273),r.e(7081)]).then(r.bind(r,17081));if(!a||!o(a.plan,"STARTER"))return n.NextResponse.json({error:"Funcionalidade exclusiva para planos Starter, Pro e Enterprise. Fa\xe7a upgrade para aceder."},{status:403});let{templateId:i,sectionId:s,empresaId:m,avisoId:v,customContext:f,modelId:A="claude-4-5-sonnet"}=await e.json(),h=u.jd[A];if(!h)return n.NextResponse.json({error:"Modelo de IA inv\xe1lido"},{status:400});if(!i||!s)return n.NextResponse.json({error:"Template e sec\xe7\xe3o s\xe3o obrigat\xf3rios"},{status:400});let T=(0,p.l3)(i);if(!T)return n.NextResponse.json({error:"Template n\xe3o encontrado"},{status:404});let P=T.sections.find(e=>e.id===s);if(!P)return n.NextResponse.json({error:"Sec\xe7\xe3o n\xe3o encontrada"},{status:404});let E=null;m&&(E=await l._B.empresa.findUnique({where:{id:m}}));let R=null;v&&(R=await l._B.aviso.findUnique({where:{id:v}}));let I={empresa:E?{nome:E.nome,nipc:E.nipc,setor:E.setor,dimensao:E.dimensao,regiao:E.regiao,cae:E.cae||"",emprego:E.numeroTrabalhadores||0,volumeNegocios:E.volumeNegocios||0}:{},aviso:R?{nome:R.nome,portal:R.portal,programa:R.programa,taxa:R.taxa||"50%"}:{},projeto:f?.projeto||{}},j=P.aiPrompt;Object.entries(I).forEach(([e,t])=>{Object.entries(t).forEach(([t,r])=>{j=j.replace(`{{${e}.${t}}}`,String(r||"N/A"))})});let q="";if(x)try{let e=await g(P.title,P.description,i,3);e.examples.length>0&&(q=`

EXEMPLOS DE CANDIDATURAS APROVADAS:
${e.examples.map((e,t)=>`[Exemplo ${t+1} - ${e.source}]
${e.content}
`).join("\n")}`,console.log(`[AI Writer] RAG: ${e.examples.length} exemplos em ${e.latencyMs}ms`))}catch(e){console.warn("[AI Writer] RAG fallback:",e.message)}let O=`
TAREFA: Escrever a sec\xe7\xe3o "${P.title}"
DESCRI\xc7\xc3O: ${P.description}
LIMITE: ${P.maxLength} caracteres

CONTEXTO DO PONTO:
${j}
${q}

NOTAS ADICIONAIS DO UTILIZADOR:
${f?.notes||"Nenhuma nota adicional."}

INSTRU\xc7\xc3O FINAL:
Escreve APENAS o texto da sec\xe7\xe3o. Nada de "Aqui est\xe1 o texto" ou introdu\xe7\xf5es.
Inspira-te nos exemplos de candidaturas aprovadas quando dispon\xedveis.
`;if(!u.qb)return n.NextResponse.json({error:"OpenRouter n\xe3o configurado - OPENROUTER_API_KEY em falta"},{status:503});let w=await u.qb.chat.completions.create({model:h.id,messages:[{role:"system",content:u.s6},{role:"user",content:O}],temperature:.7,max_tokens:4e3}),C=w.choices[0]?.message?.content||"";if(!C)throw Error("Falha ao gerar conte\xfado (resposta vazia)");return n.NextResponse.json({success:!0,section:{id:P.id,title:P.title},content:C,characterCount:C.length,maxLength:P.maxLength,model:h.name,provider:h.provider})}catch(e){return console.error("AI Writer error:",e),n.NextResponse.json({error:e.message||"Erro ao gerar conte\xfado"},{status:500})}}async function f(){let{TEMPLATES:e}=await Promise.resolve().then(r.bind(r,13275)),t=Object.values(e).map(e=>({id:e.id,name:e.name,portal:e.portal,description:e.description,sectionsCount:e.sections.length}));return n.NextResponse.json({templates:t})}let A=new o.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/writer/generate/route",pathname:"/api/writer/generate",filename:"route",bundlePath:"app/api/writer/generate/route"},resolvedPagePath:"/Users/bilal/Programaçao/TA consulting pltaform ai/TA-Consulting-Platform/app/api/writer/generate/route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:h,staticGenerationAsyncStorage:T,serverHooks:P}=A,E="/api/writer/generate/route";function R(){return(0,s.patchFetch)({serverHooks:P,staticGenerationAsyncStorage:T})}},90455:(e,t,r)=>{"use strict";r.d(t,{L:()=>c});var a=r(13539),o=r(53797),i=r(42023),s=r.n(i),n=r(71244);let c={adapter:(()=>{try{return(0,a.N)(n._B)}catch{return}})(),session:{strategy:"jwt"},pages:{signIn:"/auth/login"},providers:[(0,o.Z)({name:"credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;let t=await n._B.user.findUnique({where:{email:e.email}});return t&&t.password&&await s().compare(e.password,t.password)?{id:t.id,email:t.email,name:t.name,role:t.role}:null}})],callbacks:{jwt:async({token:e,user:t})=>(t&&(e.role=t.role),e),session:async({session:e,token:t})=>(t&&e.user&&(e.user.id=t.sub,e.user.role=t.role),e)}}},41620:(e,t,r)=>{"use strict";r.d(t,{jd:()=>s,qb:()=>i,s6:()=>n});var a=r(91088);let o=process.env.OPENROUTER_API_KEY;o||console.warn("⚠️ OPENROUTER_API_KEY not set");let i=o?new a.ZP({apiKey:o,baseURL:"https://openrouter.ai/api/v1",defaultHeaders:{"HTTP-Referer":process.env.NEXTAUTH_URL||"http://localhost:3000","X-Title":"TA Consulting Platform"}}):null,s={"llama-3-3-70b":{id:"meta-llama/llama-3.3-70b-instruct:free",name:"LLaMA 3.3 70B",provider:"Meta",description:"Master Storyteller. Excelente para narrativas longas e di\xe1logos. Top 5 LMArena Open-Source.",tier:"free",premium:!1,recommended:!0},"qwen-2-5-72b":{id:"qwen/qwen-2.5-72b-instruct:free",name:"Qwen 2.5 72B",provider:"Alibaba",description:"Precis\xe3o t\xe9cnica superior. Ideal para mem\xf3rias descritivas e textos formais.",tier:"free",premium:!1,recommended:!0},"deepseek-r1":{id:"deepseek/deepseek-r1:free",name:"DeepSeek R1",provider:"DeepSeek",description:"Racioc\xednio par com GPT-4. Open-source, gratuito, excelente para an\xe1lises.",tier:"free",premium:!1,recommended:!1},"gemma-3-27b":{id:"google/gemma-3-27b-it:free",name:"Gemma 3 27B",provider:"Google",description:"Brainstorming Buddy. R\xe1pido para ideias e esbo\xe7os iniciais.",tier:"free",premium:!1,recommended:!1},"mistral-small":{id:"mistralai/mistral-small:free",name:"Mistral Small",provider:"Mistral AI",description:"Leve e r\xe1pido. Bom para rascunhos r\xe1pidos e itera\xe7\xf5es.",tier:"free",premium:!1,recommended:!1},"claude-4-5-sonnet":{id:"anthropic/claude-sonnet-4",name:"Claude Sonnet 4",provider:"Anthropic",description:"O workhorse para Mem\xf3rias Descritivas. Equil\xedbrio perfeito qualidade/custo. (AoT Dec 2025)",tier:"paid",premium:!1,recommended:!0},"claude-opus-4-5":{id:"anthropic/claude-opus-4",name:"Claude Opus 4",provider:"Anthropic",description:"Coding benchmark #1 mundial. Para sec\xe7\xf5es cr\xedticas e workflows agentic. (AoT Dec 2025)",tier:"paid",premium:!0,recommended:!1},"mistral-large-3":{id:"mistralai/mistral-large-2512",name:"Mistral Large 3",provider:"Mistral AI",description:"Dezembro 2025. 675B MoE. Especialista em normas Europeias, Apache 2.0. (AoT Dec 2025)",tier:"paid",premium:!1,recommended:!1},"gpt-4o":{id:"openai/gpt-4o",name:"GPT-4o",provider:"OpenAI",description:"Multimodal, r\xe1pido. Bom para tarefas mistas texto+an\xe1lise.",tier:"paid",premium:!0,recommended:!1}};Object.entries(s).filter(([e,t])=>"free"===t.tier).map(([e])=>e),Object.entries(s).filter(([e,t])=>"paid"===t.tier).map(([e])=>e),Object.entries(s).filter(([e,t])=>t.recommended).map(([e])=>e);let n=`\xc9s um consultor s\xe9nior especialista em fundos europeus (Portugal 2030), treinado com os standards do Project AM\xc1LIA.
A tua miss\xe3o \xe9 produzir documenta\xe7\xe3o t\xe9cnica de elite para candidaturas a financiamento p\xfablico.

DIRETIVAS LINGU\xcdSTICAS ABSOLUTAS (PT-PT):
1. Apenas Portugu\xeas Europeu de norma culta. Toler\xe2ncia zero para brasileirismos.
   - ERRADO: "Equipe", "Usu\xe1rio", "Tela", "Planejamento", "Registro", "A\xe7\xe3o".
   - CORRETO: "Equipa", "Utilizador", "Ecr\xe3", "Planeamento", "Registo", "Ac\xe3o".
2. Sintaxe: Usa a constru\xe7\xe3o "a fazer" (infinitivo gerundivo) preferencialmente ao ger\xfandio ("fazendo"), salvo se natural.
3. Tom: Institucional, s\xf3brio, anal\xedtico e orientado a m\xe9tricas. Evita adjetiva\xe7\xe3o vazia ("inovador", "disruptivo") sem substancia\xe7\xe3o.

ESTRUTURA:
- Responde com densidade de informa\xe7\xe3o.
- Privilegia listas estruturadas e dados quantitativos.
- Nunca uses "Ol\xe1" ou "Aqui est\xe1". Entrega apenas o conte\xfado.`},21369:(e,t,r)=>{"use strict";r.d(t,{Rn:()=>o,u:()=>i});var a=r(24263);r(92048),r(55315);let o="gemini-2.5-flash";async function i(e){let t=function(){let e=process.env.GEMINI_API_KEY;if(!e)throw Error("GEMINI_API_KEY not set");return e}(),r={contents:[{parts:[{text:e.prompt}]}],tools:[{file_search:{file_search_store_names:[e.storeName],...e.metadataFilter?{metadata_filter:e.metadataFilter}:{}}}],generationConfig:{temperature:e.temperature??.1,maxOutputTokens:e.maxOutputTokens??1024}},o=`https://generativelanguage.googleapis.com/v1beta/models/${e.model}:generateContent?key=${t}`,i=(await a.default.post(o,r,{headers:{"Content-Type":"application/json"},timeout:18e4})).data,s=i?.candidates?.[0],n=function(e){let t=e?.content?.parts;return Array.isArray(t)?t.map(e=>e.text).filter(Boolean).join(""):"string"==typeof e?.content?e.content:""}(s),c=i?.usageMetadata||{},d=s?.groundingMetadata||s?.grounding_metadata,p=function(e){if(!e)return{citationCount:0,citedSources:[]};let t=e?.citations||e?.citationSources||e?.sourceCitations,r=e?.groundingChunks||e?.grounding_chunks,a=[];if(Array.isArray(t))for(let e of t){let t=e?.uri||e?.sourceUri||e?.source_uri,r=e?.title||e?.sourceTitle||e?.source_title,o=e?.source||e?.fileName||e?.file_name;a.push({source:"string"==typeof o?o:void 0,title:"string"==typeof r?r:void 0,uri:"string"==typeof t?t:void 0})}else if(Array.isArray(r))for(let e of r){let t=e?.retrievedContext||e?.retrieved_context||{},r=t?.uri||t?.sourceUri||t?.source_uri,o=t?.title||t?.sourceTitle||t?.source_title,i=t?.source||t?.name||t?.fileName||t?.file_name;(r||o||i)&&a.push({source:"string"==typeof i?i:void 0,title:"string"==typeof o?o:void 0,uri:"string"==typeof r?r:void 0})}let o=new Map;for(let e of a){let t=`${e.uri||""}|${e.source||""}|${e.title||""}`;o.has(t)||o.set(t,e)}return{citationCount:Array.isArray(t)?t.length:o.size,citedSources:Array.from(o.values())}}(d);return{text:n,usage:{promptTokenCount:c.promptTokenCount||0,candidatesTokenCount:c.candidatesTokenCount||0,totalTokenCount:c.totalTokenCount||(c.promptTokenCount||0)+(c.candidatesTokenCount||0)},groundingMetadata:d,citations:p,raw:i}}},13275:(e,t,r)=>{"use strict";r.d(t,{TEMPLATES:()=>a,l3:()=>o});let a={"pt2030-inovacao":{id:"pt2030-inovacao",name:"SI Inova\xe7\xe3o Produtiva - PT2030",portal:"PORTUGAL2030",description:"Template para candidaturas ao Sistema de Incentivos \xe0 Inova\xe7\xe3o Produtiva",createdAt:new Date,updatedAt:new Date,sections:[{id:"resumo",title:"Resumo do Projeto",description:"S\xedntese do projeto em linguagem acess\xedvel",placeholder:"Descreva o projeto de forma sucinta, incluindo objetivos principais, inova\xe7\xe3o e impacto esperado...",aiPrompt:`Gera um resumo executivo para uma candidatura PT2030, baseado na informa\xe7\xe3o da empresa:
- Nome: {{empresa.nome}}
- Setor: {{empresa.setor}}
- Objetivo do projeto: {{projeto.objetivo}}

O resumo deve:
1. Ter m\xe1ximo 500 palavras
2. Destacar a inova\xe7\xe3o do projeto
3. Mencionar impacto econ\xf3mico esperado
4. Usar linguagem formal mas acess\xedvel
5. Seguir as guidelines do Portugal 2030`,maxLength:3e3,required:!0,order:1},{id:"caracterizacao",title:"Caracteriza\xe7\xe3o da Empresa",description:"Apresenta\xe7\xe3o da empresa promotora",placeholder:"Descreva a empresa, a sua hist\xf3ria, experi\xeancia relevante e capacidade t\xe9cnica...",aiPrompt:`Gera a caracteriza\xe7\xe3o da empresa para candidatura PT2030:
- Nome: {{empresa.nome}}
- NIPC: {{empresa.nipc}}
- Setor: {{empresa.setor}}
- Dimens\xe3o: {{empresa.dimensao}}
- CAE: {{empresa.cae}}
- Regi\xe3o: {{empresa.regiao}}

Incluir:
1. Historial e experi\xeancia
2. Capacidade t\xe9cnica e recursos humanos
3. Posicionamento no mercado
4. Resultados anteriores relevantes`,maxLength:5e3,required:!0,order:2},{id:"inovacao",title:"Componente de Inova\xe7\xe3o",description:"Descri\xe7\xe3o da inova\xe7\xe3o proposta",placeholder:"Explique em que consiste a inova\xe7\xe3o, o seu car\xe1ter diferenciador e vantagens competitivas...",aiPrompt:`Descreve a componente de inova\xe7\xe3o do projeto:
- Tipo de inova\xe7\xe3o: {{projeto.tipoInovacao}}
- Descri\xe7\xe3o t\xe9cnica: {{projeto.descricaoTecnica}}

Estrutura:
1. Natureza da inova\xe7\xe3o (produto/processo/organizacional)
2. Estado da arte e gaps identificados
3. Proposta inovadora e diferencia\xe7\xe3o
4. Propriedade intelectual (se aplic\xe1vel)
5. Potencial de replica\xe7\xe3o`,maxLength:6e3,required:!0,order:3},{id:"plano-investimentos",title:"Plano de Investimentos",description:"Detalhamento dos investimentos previstos",placeholder:"Liste os investimentos por categoria, valores e cronograma...",aiPrompt:`Estrutura o plano de investimentos:
- Montante total: {{projeto.montanteTotal}}
- Categorias: {{projeto.categorias}}
- Per\xedodo: {{projeto.periodo}}

Organizar por:
1. Investimentos corp\xf3reos (equipamentos, obras)
2. Investimentos incorp\xf3reos (software, patentes)
3. Despesas de funcionamento eleg\xedveis
4. Cronograma de execu\xe7\xe3o`,maxLength:4e3,required:!0,order:4},{id:"impacto",title:"Impacto Econ\xf3mico e Social",description:"Resultados esperados do projeto",placeholder:"Quantifique os impactos esperados: emprego, volume de neg\xf3cios, exporta\xe7\xf5es...",aiPrompt:`Descreve o impacto esperado do projeto:
- Emprego atual: {{empresa.emprego}}
- VN atual: {{empresa.volumeNegocios}}

Incluir:
1. Cria\xe7\xe3o de emprego (qualificado)
2. Aumento do volume de neg\xf3cios
3. Impacto nas exporta\xe7\xf5es
4. Contributo para a transi\xe7\xe3o digital/verde
5. Impacto regional/local`,maxLength:4e3,required:!0,order:5},{id:"orcamento",title:"Quadro de Financiamento",description:"Estrutura de financiamento do projeto",placeholder:"Detalhe as fontes de financiamento: incentivo solicitado, capitais pr\xf3prios, outros...",aiPrompt:`Estrutura o quadro de financiamento:
- Investimento total: {{projeto.investimentoTotal}}
- Taxa de incentivo esperada: {{aviso.taxa}}

Calcular:
1. Incentivo n\xe3o reembols\xe1vel
2. Capitais pr\xf3prios necess\xe1rios
3. Outros financiamentos (se aplic\xe1vel)
4. Verificar regras de minimis`,maxLength:2e3,required:!0,order:6}]},"prr-digital":{id:"prr-digital",name:"Transi\xe7\xe3o Digital - PRR",portal:"PRR",description:"Template para candidaturas de Transi\xe7\xe3o Digital no PRR",createdAt:new Date,updatedAt:new Date,sections:[{id:"resumo",title:"S\xedntese do Projeto",description:"Resumo executivo do projeto de digitaliza\xe7\xe3o",placeholder:"Descreva o projeto de transforma\xe7\xe3o digital...",aiPrompt:`Gera resumo para projeto de transi\xe7\xe3o digital PRR:
- Empresa: {{empresa.nome}}
- \xc1rea de digitaliza\xe7\xe3o: {{projeto.area}}

Focar em:
1. Maturidade digital atual
2. Transforma\xe7\xe3o proposta
3. Tecnologias a implementar
4. Resultados esperados`,maxLength:2500,required:!0,order:1},{id:"diagnostico",title:"Diagn\xf3stico Digital",description:"Avalia\xe7\xe3o do estado atual de maturidade digital",placeholder:"Avalie o n\xedvel de digitaliza\xe7\xe3o atual da empresa...",aiPrompt:`Gera diagn\xf3stico de maturidade digital:
- Sistemas atuais: {{empresa.sistemas}}
- Processos digitalizados: {{empresa.processosDigitais}}

Avaliar:
1. Infraestrutura tecnol\xf3gica
2. Compet\xeancias digitais
3. Processos e automa\xe7\xe3o
4. Presen\xe7a digital
5. Ciberseguran\xe7a`,maxLength:4e3,required:!0,order:2},{id:"plano-digital",title:"Plano de Digitaliza\xe7\xe3o",description:"Estrat\xe9gia e a\xe7\xf5es de transforma\xe7\xe3o digital",placeholder:"Detalhe as a\xe7\xf5es de digitaliza\xe7\xe3o previstas...",aiPrompt:`Estrutura o plano de digitaliza\xe7\xe3o:
- Objetivos: {{projeto.objetivos}}
- Investimento: {{projeto.investimento}}

Incluir:
1. A\xe7\xf5es priorit\xe1rias
2. Tecnologias a implementar
3. Cronograma de implementa\xe7\xe3o
4. Indicadores de sucesso`,maxLength:5e3,required:!0,order:3}]}};function o(e){return a[e]||null}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[9276,2776,5972,9637,2749,4263,1088,6147,1244],()=>r(30694));module.exports=a})();