"use strict";(()=>{var e={};e.id=4667,e.ids=[4667,7081],e.modules={53524:e=>{e.exports=require("@prisma/client")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},5960:(e,a,r)=>{r.r(a),r.d(a,{originalPathname:()=>R,patchFetch:()=>T,requestAsyncStorage:()=>E,routeModule:()=>f,serverHooks:()=>P,staticGenerationAsyncStorage:()=>h});var o={};r.r(o),r.d(o,{POST:()=>v,dynamic:()=>x,maxDuration:()=>g});var t=r(49303),i=r(88716),s=r(60670),n=r(87070),d=r(75571),p=r(90455),c=r(13275),l=r(71244),m=r(41620),u=r(17081);let x="force-dynamic",g=120;async function v(e){try{let a=await (0,d.getServerSession)(p.L);if(!a?.user?.email)return n.NextResponse.json({error:"Autentica\xe7\xe3o necess\xe1ria"},{status:401});let r=await l._B.user.findUnique({where:{email:a.user.email},select:{id:!0,plan:!0}});if(!r||!(0,u.canAccessFeature)(r.plan,"STARTER"))return n.NextResponse.json({error:"Funcionalidade exclusiva para planos Starter, Pro e Enterprise."},{status:403});let{templateId:o,empresaId:t,avisoId:i,customContext:s={},modelId:x="claude-4-5-sonnet",sectionsToGenerate:g}=await e.json(),v=m.jd[x];if(!v)return n.NextResponse.json({error:"Modelo de IA inv\xe1lido"},{status:400});if(!o)return n.NextResponse.json({error:"Template \xe9 obrigat\xf3rio"},{status:400});let f=(0,c.l3)(o);if(!f)return n.NextResponse.json({error:"Template n\xe3o encontrado"},{status:404});let E=null;t&&(E=await l._B.empresa.findUnique({where:{id:t}}));let h=null;i&&(h=await l._B.aviso.findUnique({where:{id:i}}));let P={empresa:E?{nome:E.nome,nipc:E.nipc,setor:E.setor,dimensao:E.dimensao,regiao:E.regiao,cae:E.cae||"",emprego:E.numeroTrabalhadores||0,volumeNegocios:E.volumeNegocios||0}:{},aviso:h?{nome:h.nome,portal:h.portal,programa:h.programa,taxa:h.taxa||"50%"}:{},projeto:s?.projeto||{}},R=g&&g.length>0?f.sections.filter(e=>g.includes(e.id)):f.sections,T=[],A=0,I=0;for(let e of R)try{let a=e.aiPrompt;Object.entries(P).forEach(([e,r])=>{Object.entries(r).forEach(([r,o])=>{a=a.replace(`{{${e}.${r}}}`,String(o||"N/A"))})});let r=`
TAREFA: Escrever a sec\xe7\xe3o "${e.title}"
DESCRI\xc7\xc3O: ${e.description}
LIMITE: ${e.maxLength} caracteres

CONTEXTO DO PONTO:
${a}

NOTAS ADICIONAIS:
${s?.notes||"Nenhuma nota adicional."}

INSTRU\xc7\xc3O: Escreve APENAS o texto da sec\xe7\xe3o. Nada de "Aqui est\xe1 o texto" ou introdu\xe7\xf5es.
`;if(!m.qb)throw Error("OpenRouter n\xe3o configurado");let o=await m.qb.chat.completions.create({model:v.id,messages:[{role:"system",content:m.s6},{role:"user",content:r}],temperature:.7,max_tokens:4e3}),t=o.choices[0]?.message?.content||"";if(!t)throw Error("Resposta vazia do modelo");T.push({id:e.id,title:e.title,content:t,characterCount:t.length,maxLength:e.maxLength,status:"success"}),A++}catch(a){console.error(`[Full Gen] Error generating section ${e.id}:`,a.message),T.push({id:e.id,title:e.title,content:"",characterCount:0,maxLength:e.maxLength,status:"error",error:a.message}),I++}return console.log(`[Full Gen] Completed: ${A}/${R.length} sections for user ${r.id}`),n.NextResponse.json({success:!0,template:{id:f.id,name:f.name,portal:f.portal},sections:T,summary:{total:R.length,success:A,errors:I,totalCharacters:T.reduce((e,a)=>e+a.characterCount,0)},model:v.name,empresa:E?{id:E.id,nome:E.nome}:null,aviso:h?{id:h.id,nome:h.nome}:null})}catch(e){return console.error("[Full Gen] Error:",e),n.NextResponse.json({error:e.message||"Erro ao gerar candidatura"},{status:500})}}let f=new t.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/writer/generate-full/route",pathname:"/api/writer/generate-full",filename:"route",bundlePath:"app/api/writer/generate-full/route"},resolvedPagePath:"/Users/bilal/Programaçao/TA consulting pltaform ai/TA-Consulting-Platform/app/api/writer/generate-full/route.ts",nextConfigOutput:"standalone",userland:o}),{requestAsyncStorage:E,staticGenerationAsyncStorage:h,serverHooks:P}=f,R="/api/writer/generate-full/route";function T(){return(0,s.patchFetch)({serverHooks:P,staticGenerationAsyncStorage:h})}},90455:(e,a,r)=>{r.d(a,{L:()=>d});var o=r(13539),t=r(53797),i=r(42023),s=r.n(i),n=r(71244);let d={adapter:(()=>{try{return(0,o.N)(n._B)}catch{return}})(),session:{strategy:"jwt"},pages:{signIn:"/auth/login"},providers:[(0,t.Z)({name:"credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;let a=await n._B.user.findUnique({where:{email:e.email}});return a&&a.password&&await s().compare(e.password,a.password)?{id:a.id,email:a.email,name:a.name,role:a.role}:null}})],callbacks:{jwt:async({token:e,user:a})=>(a&&(e.role=a.role),e),session:async({session:e,token:a})=>(a&&e.user&&(e.user.id=a.sub,e.user.role=a.role),e)}}},41620:(e,a,r)=>{r.d(a,{jd:()=>s,qb:()=>i,s6:()=>n});var o=r(91088);let t=process.env.OPENROUTER_API_KEY;t||console.warn("⚠️ OPENROUTER_API_KEY not set");let i=t?new o.ZP({apiKey:t,baseURL:"https://openrouter.ai/api/v1",defaultHeaders:{"HTTP-Referer":process.env.NEXTAUTH_URL||"http://localhost:3000","X-Title":"TA Consulting Platform"}}):null,s={"llama-3-3-70b":{id:"meta-llama/llama-3.3-70b-instruct:free",name:"LLaMA 3.3 70B",provider:"Meta",description:"Master Storyteller. Excelente para narrativas longas e di\xe1logos. Top 5 LMArena Open-Source.",tier:"free",premium:!1,recommended:!0},"qwen-2-5-72b":{id:"qwen/qwen-2.5-72b-instruct:free",name:"Qwen 2.5 72B",provider:"Alibaba",description:"Precis\xe3o t\xe9cnica superior. Ideal para mem\xf3rias descritivas e textos formais.",tier:"free",premium:!1,recommended:!0},"deepseek-r1":{id:"deepseek/deepseek-r1:free",name:"DeepSeek R1",provider:"DeepSeek",description:"Racioc\xednio par com GPT-4. Open-source, gratuito, excelente para an\xe1lises.",tier:"free",premium:!1,recommended:!1},"gemma-3-27b":{id:"google/gemma-3-27b-it:free",name:"Gemma 3 27B",provider:"Google",description:"Brainstorming Buddy. R\xe1pido para ideias e esbo\xe7os iniciais.",tier:"free",premium:!1,recommended:!1},"mistral-small":{id:"mistralai/mistral-small:free",name:"Mistral Small",provider:"Mistral AI",description:"Leve e r\xe1pido. Bom para rascunhos r\xe1pidos e itera\xe7\xf5es.",tier:"free",premium:!1,recommended:!1},"claude-4-5-sonnet":{id:"anthropic/claude-sonnet-4",name:"Claude Sonnet 4",provider:"Anthropic",description:"O workhorse para Mem\xf3rias Descritivas. Equil\xedbrio perfeito qualidade/custo. (AoT Dec 2025)",tier:"paid",premium:!1,recommended:!0},"claude-opus-4-5":{id:"anthropic/claude-opus-4",name:"Claude Opus 4",provider:"Anthropic",description:"Coding benchmark #1 mundial. Para sec\xe7\xf5es cr\xedticas e workflows agentic. (AoT Dec 2025)",tier:"paid",premium:!0,recommended:!1},"mistral-large-3":{id:"mistralai/mistral-large-2512",name:"Mistral Large 3",provider:"Mistral AI",description:"Dezembro 2025. 675B MoE. Especialista em normas Europeias, Apache 2.0. (AoT Dec 2025)",tier:"paid",premium:!1,recommended:!1},"gpt-4o":{id:"openai/gpt-4o",name:"GPT-4o",provider:"OpenAI",description:"Multimodal, r\xe1pido. Bom para tarefas mistas texto+an\xe1lise.",tier:"paid",premium:!0,recommended:!1}};Object.entries(s).filter(([e,a])=>"free"===a.tier).map(([e])=>e),Object.entries(s).filter(([e,a])=>"paid"===a.tier).map(([e])=>e),Object.entries(s).filter(([e,a])=>a.recommended).map(([e])=>e);let n=`\xc9s um consultor s\xe9nior especialista em fundos europeus (Portugal 2030), treinado com os standards do Project AM\xc1LIA.
A tua miss\xe3o \xe9 produzir documenta\xe7\xe3o t\xe9cnica de elite para candidaturas a financiamento p\xfablico.

DIRETIVAS LINGU\xcdSTICAS ABSOLUTAS (PT-PT):
1. Apenas Portugu\xeas Europeu de norma culta. Toler\xe2ncia zero para brasileirismos.
   - ERRADO: "Equipe", "Usu\xe1rio", "Tela", "Planejamento", "Registro", "A\xe7\xe3o".
   - CORRETO: "Equipa", "Utilizador", "Ecr\xe3", "Planeamento", "Registo", "Ac\xe3o".
2. Sintaxe: Usa a constru\xe7\xe3o "a fazer" (infinitivo gerundivo) preferencialmente ao ger\xfandio ("fazendo"), salvo se natural.
3. Tom: Institucional, s\xf3brio, anal\xedtico e orientado a m\xe9tricas. Evita adjetiva\xe7\xe3o vazia ("inovador", "disruptivo") sem substancia\xe7\xe3o.

ESTRUTURA:
- Responde com densidade de informa\xe7\xe3o.
- Privilegia listas estruturadas e dados quantitativos.
- Nunca uses "Ol\xe1" ou "Aqui est\xe1". Entrega apenas o conte\xfado.`},17081:(e,a,r)=>{r.d(a,{canAccessFeature:()=>t}),r(69206),r(71244);let o={FREE:0,STARTER:1,PRO:2,ENTERPRISE:3};function t(e,a){return(o[e?.toUpperCase()||"FREE"]||0)>=o[a]}},69206:(e,a,r)=>{r.d(a,{Ag:()=>i,E1:()=>n,Mc:()=>d,Xf:()=>s});var o=r(44273);let t=process.env.STRIPE_SECRET_KEY;t||console.warn("⚠️ STRIPE_SECRET_KEY not set - Stripe features disabled");let i=t?new o.Z(t,{apiVersion:"2024-11-20.acacia",typescript:!0}):null,s={FREE:{id:"free",name:"Free",price:0,priceId:null,features:["3 avisos/m\xeas","Chat b\xe1sico com IA","Alertas limitados"],limits:{avisos:3,chat:10,empresas:1}},STARTER:{id:"starter",name:"Starter",price:29,priceId:process.env.STRIPE_STARTER_PRICE_ID||"price_starter",features:["Avisos ilimitados","Chat IA ilimitado","Smart Matching","Alertas email","5 empresas"],limits:{avisos:-1,chat:-1,empresas:5}},PRO:{id:"pro",name:"Pro",price:79,priceId:process.env.STRIPE_PRO_PRICE_ID||"price_pro",features:["Tudo do Starter","Templates de candidatura","AI Writer (beta)","Export PDF","Empresas ilimitadas","Suporte priorit\xe1rio"],limits:{avisos:-1,chat:-1,empresas:-1}},ENTERPRISE:{id:"enterprise",name:"Enterprise",price:199,priceId:process.env.STRIPE_ENTERPRISE_PRICE_ID||"price_enterprise",features:["Tudo do Pro","White-label","API dedicada","Onboarding personalizado","SLA garantido"],limits:{avisos:-1,chat:-1,empresas:-1}}};function n(e){return Object.values(s).find(a=>a.priceId===e)||null}async function d({priceId:e,customerId:a,successUrl:r,cancelUrl:o}){if(!i)throw Error("Stripe not configured - STRIPE_SECRET_KEY missing");return await i.checkout.sessions.create({mode:"subscription",payment_method_types:["card"],line_items:[{price:e,quantity:1}],customer:a,success_url:r,cancel_url:o,allow_promotion_codes:!0})}},13275:(e,a,r)=>{r.d(a,{TEMPLATES:()=>o,l3:()=>t});let o={"pt2030-inovacao":{id:"pt2030-inovacao",name:"SI Inova\xe7\xe3o Produtiva - PT2030",portal:"PORTUGAL2030",description:"Template para candidaturas ao Sistema de Incentivos \xe0 Inova\xe7\xe3o Produtiva",createdAt:new Date,updatedAt:new Date,sections:[{id:"resumo",title:"Resumo do Projeto",description:"S\xedntese do projeto em linguagem acess\xedvel",placeholder:"Descreva o projeto de forma sucinta, incluindo objetivos principais, inova\xe7\xe3o e impacto esperado...",aiPrompt:`Gera um resumo executivo para uma candidatura PT2030, baseado na informa\xe7\xe3o da empresa:
- Nome: {{empresa.nome}}
- Setor: {{empresa.setor}}
- Objetivo do projeto: {{projeto.objetivo}}

O resumo deve:
1. Ter m\xe1ximo 500 palavras
2. Destacar a inova\xe7\xe3o do projeto
3. Mencionar impacto econ\xf3mico esperado
4. Usar linguagem formal mas acess\xedvel
5. Seguir as guidelines do Portugal 2030`,maxLength:3e3,required:!0,order:1},{id:"caracterizacao",title:"Caracteriza\xe7\xe3o da Empresa",description:"Apresenta\xe7\xe3o da empresa promotora",placeholder:"Descreva a empresa, a sua hist\xf3ria, experi\xeancia relevante e capacidade t\xe9cnica...",aiPrompt:`Gera a caracteriza\xe7\xe3o da empresa para candidatura PT2030:
- Nome: {{empresa.nome}}
- NIPC: {{empresa.nipc}}
- Setor: {{empresa.setor}}
- Dimens\xe3o: {{empresa.dimensao}}
- CAE: {{empresa.cae}}
- Regi\xe3o: {{empresa.regiao}}

Incluir:
1. Historial e experi\xeancia
2. Capacidade t\xe9cnica e recursos humanos
3. Posicionamento no mercado
4. Resultados anteriores relevantes`,maxLength:5e3,required:!0,order:2},{id:"inovacao",title:"Componente de Inova\xe7\xe3o",description:"Descri\xe7\xe3o da inova\xe7\xe3o proposta",placeholder:"Explique em que consiste a inova\xe7\xe3o, o seu car\xe1ter diferenciador e vantagens competitivas...",aiPrompt:`Descreve a componente de inova\xe7\xe3o do projeto:
- Tipo de inova\xe7\xe3o: {{projeto.tipoInovacao}}
- Descri\xe7\xe3o t\xe9cnica: {{projeto.descricaoTecnica}}

Estrutura:
1. Natureza da inova\xe7\xe3o (produto/processo/organizacional)
2. Estado da arte e gaps identificados
3. Proposta inovadora e diferencia\xe7\xe3o
4. Propriedade intelectual (se aplic\xe1vel)
5. Potencial de replica\xe7\xe3o`,maxLength:6e3,required:!0,order:3},{id:"plano-investimentos",title:"Plano de Investimentos",description:"Detalhamento dos investimentos previstos",placeholder:"Liste os investimentos por categoria, valores e cronograma...",aiPrompt:`Estrutura o plano de investimentos:
- Montante total: {{projeto.montanteTotal}}
- Categorias: {{projeto.categorias}}
- Per\xedodo: {{projeto.periodo}}

Organizar por:
1. Investimentos corp\xf3reos (equipamentos, obras)
2. Investimentos incorp\xf3reos (software, patentes)
3. Despesas de funcionamento eleg\xedveis
4. Cronograma de execu\xe7\xe3o`,maxLength:4e3,required:!0,order:4},{id:"impacto",title:"Impacto Econ\xf3mico e Social",description:"Resultados esperados do projeto",placeholder:"Quantifique os impactos esperados: emprego, volume de neg\xf3cios, exporta\xe7\xf5es...",aiPrompt:`Descreve o impacto esperado do projeto:
- Emprego atual: {{empresa.emprego}}
- VN atual: {{empresa.volumeNegocios}}

Incluir:
1. Cria\xe7\xe3o de emprego (qualificado)
2. Aumento do volume de neg\xf3cios
3. Impacto nas exporta\xe7\xf5es
4. Contributo para a transi\xe7\xe3o digital/verde
5. Impacto regional/local`,maxLength:4e3,required:!0,order:5},{id:"orcamento",title:"Quadro de Financiamento",description:"Estrutura de financiamento do projeto",placeholder:"Detalhe as fontes de financiamento: incentivo solicitado, capitais pr\xf3prios, outros...",aiPrompt:`Estrutura o quadro de financiamento:
- Investimento total: {{projeto.investimentoTotal}}
- Taxa de incentivo esperada: {{aviso.taxa}}

Calcular:
1. Incentivo n\xe3o reembols\xe1vel
2. Capitais pr\xf3prios necess\xe1rios
3. Outros financiamentos (se aplic\xe1vel)
4. Verificar regras de minimis`,maxLength:2e3,required:!0,order:6}]},"prr-digital":{id:"prr-digital",name:"Transi\xe7\xe3o Digital - PRR",portal:"PRR",description:"Template para candidaturas de Transi\xe7\xe3o Digital no PRR",createdAt:new Date,updatedAt:new Date,sections:[{id:"resumo",title:"S\xedntese do Projeto",description:"Resumo executivo do projeto de digitaliza\xe7\xe3o",placeholder:"Descreva o projeto de transforma\xe7\xe3o digital...",aiPrompt:`Gera resumo para projeto de transi\xe7\xe3o digital PRR:
- Empresa: {{empresa.nome}}
- \xc1rea de digitaliza\xe7\xe3o: {{projeto.area}}

Focar em:
1. Maturidade digital atual
2. Transforma\xe7\xe3o proposta
3. Tecnologias a implementar
4. Resultados esperados`,maxLength:2500,required:!0,order:1},{id:"diagnostico",title:"Diagn\xf3stico Digital",description:"Avalia\xe7\xe3o do estado atual de maturidade digital",placeholder:"Avalie o n\xedvel de digitaliza\xe7\xe3o atual da empresa...",aiPrompt:`Gera diagn\xf3stico de maturidade digital:
- Sistemas atuais: {{empresa.sistemas}}
- Processos digitalizados: {{empresa.processosDigitais}}

Avaliar:
1. Infraestrutura tecnol\xf3gica
2. Compet\xeancias digitais
3. Processos e automa\xe7\xe3o
4. Presen\xe7a digital
5. Ciberseguran\xe7a`,maxLength:4e3,required:!0,order:2},{id:"plano-digital",title:"Plano de Digitaliza\xe7\xe3o",description:"Estrat\xe9gia e a\xe7\xf5es de transforma\xe7\xe3o digital",placeholder:"Detalhe as a\xe7\xf5es de digitaliza\xe7\xe3o previstas...",aiPrompt:`Estrutura o plano de digitaliza\xe7\xe3o:
- Objetivos: {{projeto.objetivos}}
- Investimento: {{projeto.investimento}}

Incluir:
1. A\xe7\xf5es priorit\xe1rias
2. Tecnologias a implementar
3. Cronograma de implementa\xe7\xe3o
4. Indicadores de sucesso`,maxLength:5e3,required:!0,order:3}]}};function t(e){return o[e]||null}}};var a=require("../../../../webpack-runtime.js");a.C(e);var r=e=>a(a.s=e),o=a.X(0,[9276,2776,5972,9637,2749,1088,4273,1244],()=>r(5960));module.exports=o})();