(()=>{var e={};e.id=2145,e.ids=[2145],e.modules={62688:e=>{function t(e){return Promise.resolve().then(()=>{var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t})}t.keys=()=>[],t.resolve=t,t.id=62688,e.exports=t},53524:e=>{"use strict";e.exports=require("@prisma/client")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{"use strict";e.exports=require("assert")},78893:e=>{"use strict";e.exports=require("buffer")},84770:e=>{"use strict";e.exports=require("crypto")},17702:e=>{"use strict";e.exports=require("events")},92048:e=>{"use strict";e.exports=require("fs")},32615:e=>{"use strict";e.exports=require("http")},32694:e=>{"use strict";e.exports=require("http2")},35240:e=>{"use strict";e.exports=require("https")},19801:e=>{"use strict";e.exports=require("os")},55315:e=>{"use strict";e.exports=require("path")},86624:e=>{"use strict";e.exports=require("querystring")},76162:e=>{"use strict";e.exports=require("stream")},74175:e=>{"use strict";e.exports=require("tty")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},27894:(e,t,a)=>{"use strict";a.r(t),a.d(t,{originalPathname:()=>y,patchFetch:()=>E,requestAsyncStorage:()=>A,routeModule:()=>S,serverHooks:()=>R,staticGenerationAsyncStorage:()=>h});var o={};a.r(o),a.d(o,{POST:()=>f,dynamic:()=>x});var r=a(49303),s=a(88716),n=a(60670),i=a(87070),c=a(75571),d=a(90455),u=a(71244);async function l(e){let t=e.body?.getReader(),a=new TextDecoder,o=new TextEncoder;if(!t)throw Error("Response body is null");return new ReadableStream({async start(e){try{let r="";for(;;){let{done:s,value:n}=await t.read();if(s)break;let i=a.decode(n,{stream:!0}),c=(r+=i).split("\n");for(let t of(r=c.pop()||"",c)){let a=t.trim();if(a&&"data: [DONE]"!==a&&a.startsWith("data: "))try{let t=a.slice(6),r=JSON.parse(t),s=r.choices?.[0]?.delta?.content||"";s&&e.enqueue(o.encode(s))}catch(e){console.warn("Erro parse SSE:",e)}}}}catch(t){console.error("Erro no stream handler:",t),e.error(t)}finally{e.close()}}})}var p=a(21067),m=a(35075);let g=p.Ry({message:p.Z_().min(1,"Mensagem \xe9 obrigat\xf3ria").max(5e3,"Mensagem demasiado longa"),conversationHistory:p.IX(p.Ry({text:p.Z_(),isBot:p.O7()})).max(50,"Hist\xf3rico demasiado longo").optional().default([])}),x="force-dynamic";async function f(e){try{let t=(0,m.H9)(e),o=(0,m.Dn)(`chatbot:${t}`,m.fp.CHATBOT);if(!o.success)return i.NextResponse.json({error:"Too Many Requests",retryAfter:o.resetIn},{status:429,headers:{"Retry-After":o.resetIn.toString()}});if(!await (0,c.getServerSession)(d.L))return i.NextResponse.json({error:"Unauthorized"},{status:401});let r=await e.json(),s=g.safeParse(r);if(!s.success)return i.NextResponse.json({error:"Valida\xe7\xe3o falhou",details:s.error.flatten().fieldErrors},{status:400});let{message:n,conversationHistory:p}=s.data,[x,f,S]=await Promise.all([u._B.aviso.findMany({take:50,orderBy:{createdAt:"desc"},select:{id:!0,nome:!0,codigo:!0,descricao:!0,portal:!0,programa:!0,linha:!0,dataInicioSubmissao:!0,dataFimSubmissao:!0,montanteMinimo:!0,montanteMaximo:!0,ativo:!0,urgente:!0}}),u._B.empresa.findMany({take:20,select:{id:!0,nome:!0,nipc:!0,setor:!0,dimensao:!0,regiao:!0}}),u._B.candidatura.findMany({take:20,orderBy:{createdAt:"desc"},include:{aviso:{select:{nome:!0,portal:!0}},empresa:{select:{nome:!0}}}})]),A=new Date,h=new Date;h.setDate(A.getDate()+14);let R=x.filter(e=>{let t=new Date(e.dataFimSubmissao);return e.ativo&&t>=A&&t<=h}),{classifyIntent:y,executeHybridQuery:E}=a(37992),v=await y(n);if("RAG_QUERY"===v.type||"HISTORICO_SEARCH"===v.type||"HYBRID"===v.type){console.log(`🔀 Chat Router: ${v.type} - ${v.reasoning}`);let e=await E(n,v,p);if("DB_DELEGATE"!==e&&"GENERAL_DELEGATE"!==e){let t=new TextEncoder,a=new ReadableStream({start(a){a.enqueue(t.encode(e)),a.close()}});return new Response(a,{headers:{"Content-Type":"text/plain; charset=utf-8"}})}}let D="",I="";try{let t=e.url.split("/api/chatbot")[0],a=await fetch(`${t}/api/alertas?prioridade=alta`);if(a.ok){let e=await a.json();e.alertas&&e.alertas.length>0&&(D=`
🚨 ALERTAS IMPORTANTES (${e.alertas.length}):
`,e.alertas.slice(0,3).forEach((e,t)=>{D+=`${t+1}. ${e.titulo}
   ${e.mensagem}
`}))}if(f.length>0){let e=await fetch(`${t}/api/recomendacoes?empresaId=${f[0].id}&limite=3&scoreMinimo=60`);if(e.ok){let t=await e.json();t.recomendacoes&&t.recomendacoes.length>0&&(I=`
✨ RECOMENDA\xc7\xd5ES IA PARA ${f[0].nome} (Top 3):
`,t.recomendacoes.forEach((e,t)=>{I+=`${t+1}. ${e.aviso.titulo}
   Score de Compatibilidade: ${e.score}%
   Prioridade: ${e.prioridade}
`,e.razoes.length>0&&(I+=`   Raz\xe3o: ${e.razoes[0]}
`)}))}}}catch(e){console.error("Erro ao buscar alertas/recomenda\xe7\xf5es:",e)}let $=`
Voc\xea \xe9 o Assistente Inteligente da TA Consulting, especializado em apoios financeiros e fundos europeus para empresas portuguesas.

DADOS DISPON\xcdVEIS:

📋 AVISOS (${x.length} total, ${R.length} urgentes):
${R.slice(0,10).map(e=>`
- ${e.nome} [${e.portal}]
  C\xf3digo: ${e.codigo}
  Programa: ${e.programa||"N/A"}
  Linha: ${e.linha||"N/A"}
  Abre: ${new Date(e.dataInicioSubmissao).toLocaleDateString("pt-PT")}
  Encerra: ${new Date(e.dataFimSubmissao).toLocaleDateString("pt-PT")}
  Montante M\xedn: ${e.montanteMinimo?`€${e.montanteMinimo.toLocaleString("pt-PT")}`:"N/A"}
  Montante M\xe1x: ${e.montanteMaximo?`€${e.montanteMaximo.toLocaleString("pt-PT")}`:"N/A"}
  Status: ${e.ativo?"Ativo":"Inativo"}
`).join("\n")}

${x.length>10?`
... e mais ${x.length-10} avisos dispon\xedveis`:""}

👥 EMPRESAS (${f.length} registadas):
${f.slice(0,5).map(e=>`
- ${e.nome} (NIPC: ${e.nipc})
  Setor: ${e.setor||"N/A"}
  Dimens\xe3o: ${e.dimensao||"N/A"}
  Regi\xe3o: ${e.regiao||"N/A"}
`).join("\n")}

📝 CANDIDATURAS (${S.length} submetidas):
${S.slice(0,5).map(e=>`
- ${e.empresa?.nome||"N/A"} → ${e.aviso?.nome||"N/A"}
  Portal: ${e.aviso?.portal||"N/A"}
  Estado: ${e.estado}
  Valor: ${e.montanteSolicitado?`€${e.montanteSolicitado.toLocaleString("pt-PT")}`:"N/A"}
  Data: ${new Date(e.createdAt).toLocaleDateString("pt-PT")}
`).join("\n")}
${D}
${I}

CAPACIDADES ESPECIAIS:
- Sistema de Recomenda\xe7\xf5es IA que analisa compatibilidade entre empresas e avisos
- Sistema de Alertas Inteligentes para prazos urgentes e oportunidades
- An\xe1lises detalhadas de compatibilidade com scoring de 0-100%
- Acesso \xe0 p\xe1gina "Recomenda\xe7\xf5es IA" no dashboard para an\xe1lises personalizadas

INSTRU\xc7\xd5ES:
1. Responda SEMPRE em portugu\xeas de Portugal
2. Use os dados reais acima para responder com precis\xe3o
3. Se o utilizador perguntar por avisos espec\xedficos, mencione t\xedtulos, datas e valores REAIS
4. Se perguntar "que avisos est\xe3o abertos", liste os avisos urgentes com detalhes
5. Seja conversacional, profissional e \xfatil
6. Use emojis apropriadamente (📋 🏢 💼 📊 ⏰ ✅)
7. Se o utilizador pedir "mais detalhes", forne\xe7a informa\xe7\xf5es espec\xedficas dos avisos mencionados anteriormente
8. Mantenha as respostas concisas mas informativas (m\xe1ximo 250 palavras)
9. NUNCA invente dados - use APENAS os dados fornecidos acima
10. Se n\xe3o tiver informa\xe7\xe3o, diga "N\xe3o tenho essa informa\xe7\xe3o neste momento"
11. Quando perguntar sobre avisos adequados para uma empresa, mencione as RECOMENDA\xc7\xd5ES IA acima
12. Se houver ALERTAS, mencione-os quando relevante para a conversa
13. Sugira sempre visitar a p\xe1gina "Recomenda\xe7\xf5es IA" para an\xe1lises detalhadas personalizadas
14. Use os scores de compatibilidade das recomenda\xe7\xf5es quando discutir adequa\xe7\xe3o de avisos
`,C=[{role:"system",content:$},...p.slice(-6).map(e=>({role:e.isBot?"assistant":"user",content:e.text})),{role:"user",content:n}],w=await fetch("https://apps.abacus.ai/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${process.env.ABACUSAI_API_KEY}`},body:JSON.stringify({model:"gpt-4.1-mini",messages:C,stream:!0,max_tokens:1e3,temperature:.7})});if(!w.ok)return console.error("Erro na API LLM:",await w.text()),i.NextResponse.json({error:"Erro ao processar resposta do assistente"},{status:500});let T=await l(w);return new Response(T,{headers:{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"no-cache",Connection:"keep-alive"}})}catch(e){return console.error("Erro no chatbot:",e),i.NextResponse.json({error:"Erro interno do servidor"},{status:500})}}let S=new r.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/chatbot/route",pathname:"/api/chatbot",filename:"route",bundlePath:"app/api/chatbot/route"},resolvedPagePath:"/Users/bilal/Programaçao/TA consulting pltaform ai/TA-Consulting-Platform/app/api/chatbot/route.ts",nextConfigOutput:"standalone",userland:o}),{requestAsyncStorage:A,staticGenerationAsyncStorage:h,serverHooks:R}=S,y="/api/chatbot/route";function E(){return(0,n.patchFetch)({serverHooks:R,staticGenerationAsyncStorage:h})}},90455:(e,t,a)=>{"use strict";a.d(t,{L:()=>c});var o=a(13539),r=a(53797),s=a(42023),n=a.n(s),i=a(71244);let c={adapter:(()=>{try{return(0,o.N)(i._B)}catch{return}})(),session:{strategy:"jwt"},pages:{signIn:"/auth/login"},providers:[(0,r.Z)({name:"credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;let t=await i._B.user.findUnique({where:{email:e.email}});return t&&t.password&&await n().compare(e.password,t.password)?{id:t.id,email:t.email,name:t.name,role:t.role}:null}})],callbacks:{jwt:async({token:e,user:t})=>(t&&(e.role=t.role),e),session:async({session:e,token:t})=>(t&&e.user&&(e.user.id=t.sub,e.user.role=t.role),e)}}},37992:(e,t,a)=>{"use strict";a.r(t),a.d(t,{classifyIntent:()=>n,executeHistoricoQuery:()=>i,executeHybridQuery:()=>c});var o=a(21369),r=a(71244);let s=["prr","p2030","p2020","pdr2020","pepac","sifide","ipdj","pares","horizon"];async function n(e){let t=e.toLowerCase(),a=function(e){let t=e.toLowerCase(),a={};for(let e of s)if(t.includes(e)){a.programa=e.toUpperCase();break}let o=e.match(/20(2[0-5])/);return o&&(a.ano=parseInt(o[0],10)),a}(e);return t.includes("quantos")&&t.includes("como")||t.includes("montante")&&t.includes("justificar")||t.includes("lista")&&t.includes("exemplo")||t.includes("candidaturas")&&t.includes("exemplo")||t.includes("candidaturas")&&t.includes("como")?{type:"HYBRID",entities:a,reasoning:"User pede dados factuais + contexto qualitativo."}:t.includes("resumo")||t.includes("sobre o que")||t.includes("explica")||t.includes("cpc")||t.includes("cae")||t.includes("despesas")||t.includes("eleg\xedveis")||t.includes("documentos necess\xe1rios")||t.includes("guia")||t.includes("como escrever")||t.includes("template")||t.includes("exemplo")||t.includes("melhor pr\xe1tica")||t.includes("melhores pr\xe1ticas")||t.includes("justificar investimento")||t.includes("justificar investimentos")||t.includes("como")&&t.includes("justificar")?{type:"RAG_QUERY",entities:a,reasoning:"User pede conte\xfado profundo/qualitativo dos documentos."}:t.includes("avisos")||t.includes("lista")&&!t.includes("candidatura")||t.includes("abertos")||t.includes("prazos")||t.includes("datas")||t.includes("pr\xf3ximos")&&!t.includes("candidatura")?{type:"DB_SEARCH",entities:a,reasoning:"User pede listagem de avisos ou metadados estruturados."}:t.includes("candidatura")||t.includes("candidaturas")||t.includes("fizemos")||t.includes("fizeste")||t.includes("submetemos")||t.includes("aprovadas")||t.includes("rejeitadas")||t.includes("montante")||t.includes("quanto")||t.includes("clientes")||t.includes("hist\xf3rico")||t.includes("passado")||t.includes("ano passado")||t.includes("\xfaltimas")?{type:"HISTORICO_SEARCH",entities:a,reasoning:"User pede dados sobre candidaturas hist\xf3ricas (SQL exacto)."}:{type:"GENERAL",entities:a,reasoning:"Conversa gen\xe9rica ou amb\xedgua."}}async function i(e,t){console.log("\uD83D\uDCCA Roteamento: SQL Hist\xf3rico (CandidaturaHistorica)");let a=e.toLowerCase();try{if(a.includes("quantas")||a.includes("quantos")){let e={};t?.programa&&(e.programa=t.programa),t?.ano&&(e.ano=t.ano);let a=await r._B.candidaturaHistorica.count({where:e}),o=await r._B.candidaturaHistorica.groupBy({by:["programa"],_count:{id:!0},where:e,orderBy:{_count:{id:"desc"}}}),s=`📊 **Total de candidaturas**: ${a}

`;return o.length>1&&(s+="**Por programa:**\n",o.forEach(e=>{s+=`- ${e.programa}: ${e._count.id}
`})),s}if(a.includes("clientes")||a.includes("empresas")){let e={};t?.programa&&(e.programa=t.programa);let a=await r._B.candidaturaHistorica.findMany({where:e,select:{cliente:!0,programa:!0,ano:!0},distinct:["cliente"],take:20,orderBy:{cliente:"asc"}}),o=`👥 **Clientes com candidaturas** (${a.length} mostrados):

`;return a.forEach((e,t)=>{o+=`${t+1}. ${e.cliente} (${e.programa}${e.ano?`, ${e.ano}`:""})
`}),o}if(t?.ano){let e=await r._B.candidaturaHistorica.findMany({where:{ano:t.ano},select:{cliente:!0,programa:!0,subPrograma:!0,totalDocumentos:!0},take:15}),a=`📅 **Candidaturas de ${t.ano}**: ${e.length} encontradas

`;return e.forEach((e,t)=>{a+=`${t+1}. ${e.cliente} - ${e.programa}${e.subPrograma?`/${e.subPrograma}`:""} (${e.totalDocumentos} docs)
`}),a}let e=await r._B.candidaturaHistorica.findMany({select:{cliente:!0,programa:!0,ano:!0,prioridade:!0},orderBy:{createdAt:"desc"},take:10}),o="\uD83D\uDCCB **\xdaltimas candidaturas registadas**:\n\n";return e.forEach((e,t)=>{o+=`${t+1}. ${e.cliente} - ${e.programa} (${e.ano||"N/A"}) [${e.prioridade}]
`}),o}catch(e){return console.error("❌ Erro SQL Hist\xf3rico:",e.message),"Ocorreu um erro ao consultar as candidaturas hist\xf3ricas."}}async function c(e,t,s){if("HISTORICO_SEARCH"===t.type)return await i(e,t.entities);if("RAG_QUERY"===t.type){console.log("\uD83E\uDD16 Roteamento: Gemini RAG");let t=process.env.GEMINI_RAG_STORE_ID;if(!t)return console.error("❌ GEMINI_RAG_STORE_ID n\xe3o configurado na ENV."),"Desculpe, o sistema de pesquisa documental est\xe1 em manuten\xe7\xe3o (Store ID em falta).";try{let{AUDITOR_SYSTEM_PROMPT:r}=a(19948),s=await (0,o.u)({model:o.Rn,prompt:`${r}

PERGUNTA: ${e}`,storeName:t,temperature:.1}),n=s.text;return s.citations&&s.citations.citedSources.length>0&&(n+="\n\n\uD83D\uDCDA Fontes consultadas:",s.citations.citedSources.forEach(e=>{let t=e.title||e.uri?.split("/").pop()||"Documento";n+=`
- ${t}`})),n}catch(e){return console.error("❌ Erro RAG Gemini:",e.message),"Desculpe, o sistema de pesquisa est\xe1 temporariamente indispon\xedvel (Gemini RAG). Por favor, tente novamente em alguns minutos."}}if("DB_SEARCH"===t.type)return console.log("\uD83D\uDCBE Roteamento: SQL DB (Avisos)"),"DB_DELEGATE";if("HYBRID"===t.type){console.log("\uD83D\uDD00 Roteamento: ADVANCED HYBRID (SQL + RAG + RRF + Re-ranking)");let s=Date.now(),{reciprocalRankFusion:n,rerankWithGemini:i,decomposeQuery:c,logRAGMetrics:d}=a(19062),u=c(e);console.log(`   📝 Decomposi\xe7\xe3o: ${u.needsDecomposition?"SIM":"N\xc3O"} (${u.subQueries.length} sub-queries)`);let l=[],p=[];try{(await r._B.candidaturaHistorica.findMany({where:t.entities?.programa?{programa:t.entities.programa}:{},select:{id:!0,cliente:!0,programa:!0,ano:!0,totalDocumentos:!0},take:20,orderBy:{createdAt:"desc"}})).forEach((e,t)=>{l.push({id:e.id,content:`${e.cliente} - ${e.programa} (${e.ano||"N/A"}) [${e.totalDocumentos} docs]`,source:"SQL",originalRank:t,metadata:e})})}catch(e){console.warn("⚠️ SQL query falhou, continuando com RAG")}let m=process.env.GEMINI_RAG_STORE_ID||process.env.GEMINI_CANDIDATURAS_STORE_ID;if(m)try{let{AUDITOR_SYSTEM_PROMPT:t}=a(19948),r=await (0,o.u)({model:o.Rn,prompt:`${t}

PERGUNTA (Procura documentos relevantes): ${e}`,storeName:m,temperature:0});r.citations?.citedSources&&r.citations.citedSources.forEach((e,t)=>{p.push({id:e.uri||`rag-${t}`,content:e.title||e.source||"Documento RAG",source:"RAG",originalRank:t,metadata:e})})}catch(e){console.warn("⚠️ RAG query falhou, continuando com SQL")}console.log(`   🔗 RRF Fusion: ${l.length} SQL + ${p.length} RAG`);let g=n(l,p,60),x=g;if(g.length>3){console.log("   \uD83D\uDD04 Re-ranking com Gemini...");try{let t=await i(e,g.slice(0,10));t.length>0&&(x=t.map(e=>({...g.find(t=>t.id===e.id),relevanceScore:e.relevanceScore})))}catch(e){console.warn("⚠️ Re-ranking falhou, usando ordem RRF")}}let f="\uD83D\uDCCA **Resultados (Hybrid SQL+RAG com RRF)**\n\n";l.length>0&&(f+=`**📋 Dados estruturados (${l.length} candidaturas):**
`,l.slice(0,5).forEach((e,t)=>{f+=`${t+1}. ${e.content}
`}),f+="\n"),p.length>0&&(f+=`**📖 Documentos relevantes (${p.length} fontes):**
`,p.slice(0,3).forEach((e,t)=>{f+=`- ${e.content}
`}),f+="\n");let S=x.filter(e=>e.sources?.length>1).length;S>0&&(f+=`
✨ ${S} resultados confirmados em ambas as fontes (SQL + RAG)
`);let A=Date.now()-s;return d({queryId:`hybrid-${Date.now()}`,query:e,timestamp:new Date,intent:"HYBRID",decomposed:u.needsDecomposition,retrievalCount:l.length+p.length,rrfApplied:!0,rerankApplied:x!==g,responseLatencyMs:A,citationCount:p.length,sources:["SQL","RAG"]}),console.log(`   ⏱️ Lat\xeancia total: ${A}ms`),f}return"GENERAL_DELEGATE"}},19062:(e,t,a)=>{"use strict";function o(e,t,a=60){let o=new Map;return e.forEach((e,t)=>{let r=o.get(e.id),s=1/(a+t);r?(r.rrfScore+=s,r.sources.includes("SQL")||r.sources.push("SQL")):o.set(e.id,{id:e.id,content:e.content,rrfScore:s,sources:["SQL"],metadata:e.metadata})}),t.forEach((e,t)=>{let r=o.get(e.id),s=1/(a+t);r?(r.rrfScore+=s,r.sources.includes("RAG")||r.sources.push("RAG")):o.set(e.id,{id:e.id,content:e.content,rrfScore:s,sources:["RAG"],metadata:e.metadata})}),Array.from(o.values()).sort((e,t)=>t.rrfScore-e.rrfScore)}async function r(e,t,a=10){let o=t.slice(0,a);if(0===o.length)return[];let r=`Avalia a relev\xe2ncia de cada documento para a pergunta do utilizador.
Para cada documento, d\xe1 um score de 0 a 100 onde:
- 100 = Responde perfeitamente \xe0 pergunta
- 75 = Muito relevante
- 50 = Parcialmente relevante
- 25 = Pouco relevante
- 0 = Irrelevante

PERGUNTA: "${e}"

DOCUMENTOS:
${o.map((e,t)=>`[${t+1}] ${e.content.slice(0,300)}...`).join("\n\n")}

Responde APENAS em formato JSON:
{
  "rankings": [
    {"doc": 1, "score": 85, "reason": "Raz\xe3o curta"},
    {"doc": 2, "score": 60, "reason": "Raz\xe3o curta"}
  ]
}`;try{let e=await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent",{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":process.env.GEMINI_API_KEY||""},body:JSON.stringify({contents:[{parts:[{text:r}]}],generationConfig:{temperature:0}})}),t=await e.json(),a=(t?.candidates?.[0]?.content?.parts?.[0]?.text||"").match(/\{[\s\S]*\}/);if(!a)return console.warn("⚠️ Re-ranking: N\xe3o conseguiu extrair JSON"),o.map((e,t)=>({id:e.id,content:e.content,relevanceScore:100-10*t,reasoning:"Ordem original mantida"}));let s=JSON.parse(a[0]),n=[];for(let e of s.rankings||[]){let t=e.doc-1;t>=0&&t<o.length&&n.push({id:o[t].id,content:o[t].content,relevanceScore:e.score,reasoning:e.reason||""})}return n.sort((e,t)=>t.relevanceScore-e.relevanceScore)}catch(e){return console.error("❌ Re-ranking falhou:",e.message),o.map((e,t)=>({id:e.id,content:e.content,relevanceScore:100-10*t,reasoning:"Fallback - ordem original"}))}}function s(e){let t=e.toLowerCase(),a=[" e "," com "," al\xe9m de "," tamb\xe9m "];a.some(e=>t.includes(e));let o=["quanto","quantos","quantas","montante","valor","total","m\xe9dia"].some(e=>t.includes(e)),r=["como","exemplo","explica","justifica","detalhe"].some(e=>t.includes(e));if(o&&r){for(let r of a)if(t.includes(r)){let t=e.split(RegExp(r,"i"));if(t.length>=2)return{original:e,subQueries:[{query:t[0].trim(),type:o?"SQL":"RAG",intent:"Parte quantitativa/factual"},{query:t[1].trim(),type:"RAG",intent:"Parte qualitativa/contextual"}],needsDecomposition:!0}}}return{original:e,subQueries:[{query:e,type:o?"SQL":r?"RAG":"HYBRID",intent:"Query simples"}],needsDecomposition:!1}}a.r(t),a.d(t,{GOLDEN_SET:()=>u,decomposeQuery:()=>s,exportMetricsForGoldenSet:()=>d,getAggregatedMetrics:()=>c,logRAGMetrics:()=>i,reciprocalRankFusion:()=>o,rerankWithGemini:()=>r,validateAgainstGoldenSet:()=>l});let n=[];function i(e){n.push(e),console.log(`📊 RAG Metrics: ${e.queryId}`,{intent:e.intent,decomposed:e.decomposed,rrfApplied:e.rrfApplied,rerankApplied:e.rerankApplied,latencyMs:e.responseLatencyMs,citations:e.citationCount})}function c(){if(0===n.length)return{count:0,avgLatency:0,avgCitations:0};let e=n.reduce((e,t)=>e+t.responseLatencyMs,0),t=n.reduce((e,t)=>e+t.citationCount,0);return{count:n.length,avgLatency:Math.round(e/n.length),avgCitations:(t/n.length).toFixed(2),byIntent:n.reduce((e,t)=>(e[t.intent]=(e[t.intent]||0)+1,e),{})}}function d(){return[...n]}let u=[{id:"GS001",query:"Quantas candidaturas PRR fizemos?",expectedIntent:"HISTORICO_SEARCH",expectedSources:["SQL"],expectedKeywords:["PRR","candidaturas"],category:"factual"},{id:"GS002",query:"Quais clientes temos no programa P2030?",expectedIntent:"HISTORICO_SEARCH",expectedSources:["SQL"],expectedKeywords:["P2030","clientes"],category:"factual"},{id:"GS003",query:"Candidaturas aprovadas em 2023",expectedIntent:"HISTORICO_SEARCH",expectedSources:["SQL"],expectedKeywords:["2023","aprovadas"],category:"factual"},{id:"GS004",query:"Qual o montante total das nossas candidaturas?",expectedIntent:"HISTORICO_SEARCH",expectedSources:["SQL"],expectedKeywords:["montante","total"],category:"factual"},{id:"GS005",query:"Como escrever uma mem\xf3ria descritiva para PRR?",expectedIntent:"RAG_QUERY",expectedSources:["RAG"],expectedKeywords:["mem\xf3ria descritiva","PRR"],category:"qualitative"},{id:"GS006",query:"Quais s\xe3o as melhores pr\xe1ticas para justificar investimentos?",expectedIntent:"RAG_QUERY",expectedSources:["RAG"],expectedKeywords:["melhores pr\xe1ticas","justificar"],category:"qualitative"},{id:"GS007",query:"Template de proposta t\xe9cnica para P2030",expectedIntent:"RAG_QUERY",expectedSources:["RAG"],expectedKeywords:["template","proposta t\xe9cnica"],category:"qualitative"},{id:"GS008",query:"Lista de candidaturas PRR com exemplos de como justificaram",expectedIntent:"HYBRID",expectedSources:["SQL","RAG"],expectedKeywords:["PRR","exemplos","justificaram"],category:"hybrid"},{id:"GS009",query:"Quantas candidaturas aprovadas e como estruturaram os or\xe7amentos?",expectedIntent:"HYBRID",expectedSources:["SQL","RAG"],expectedKeywords:["aprovadas","or\xe7amentos"],category:"hybrid"},{id:"GS010",query:"Quais avisos est\xe3o abertos agora?",expectedIntent:"DB_SEARCH",expectedSources:["DB"],expectedKeywords:["avisos","abertos"],category:"factual"},{id:"GS011",query:"Pr\xf3ximos prazos de candidatura",expectedIntent:"DB_SEARCH",expectedSources:["DB"],expectedKeywords:["prazos"],category:"factual"}];function l(e,t,a){let o=u.find(t=>t.id===e);if(!o)return{passed:!0,issues:["Query n\xe3o est\xe1 no Golden Set"]};let r=[];t!==o.expectedIntent&&r.push(`Intent: esperado ${o.expectedIntent}, obtido ${t}`);let s=o.expectedSources.filter(e=>!a.includes(e));return s.length>0&&r.push(`Sources em falta: ${s.join(", ")}`),{passed:0===r.length,issues:r}}},21369:(e,t,a)=>{"use strict";a.d(t,{Rn:()=>r,u:()=>s});var o=a(24263);a(92048),a(55315);let r="gemini-2.5-flash";async function s(e){let t=function(){let e=process.env.GEMINI_API_KEY;if(!e)throw Error("GEMINI_API_KEY not set");return e}(),a={contents:[{parts:[{text:e.prompt}]}],tools:[{file_search:{file_search_store_names:[e.storeName],...e.metadataFilter?{metadata_filter:e.metadataFilter}:{}}}],generationConfig:{temperature:e.temperature??.1,maxOutputTokens:e.maxOutputTokens??1024}},r=`https://generativelanguage.googleapis.com/v1beta/models/${e.model}:generateContent?key=${t}`,s=(await o.default.post(r,a,{headers:{"Content-Type":"application/json"},timeout:18e4})).data,n=s?.candidates?.[0],i=function(e){let t=e?.content?.parts;return Array.isArray(t)?t.map(e=>e.text).filter(Boolean).join(""):"string"==typeof e?.content?e.content:""}(n),c=s?.usageMetadata||{},d=n?.groundingMetadata||n?.grounding_metadata,u=function(e){if(!e)return{citationCount:0,citedSources:[]};let t=e?.citations||e?.citationSources||e?.sourceCitations,a=e?.groundingChunks||e?.grounding_chunks,o=[];if(Array.isArray(t))for(let e of t){let t=e?.uri||e?.sourceUri||e?.source_uri,a=e?.title||e?.sourceTitle||e?.source_title,r=e?.source||e?.fileName||e?.file_name;o.push({source:"string"==typeof r?r:void 0,title:"string"==typeof a?a:void 0,uri:"string"==typeof t?t:void 0})}else if(Array.isArray(a))for(let e of a){let t=e?.retrievedContext||e?.retrieved_context||{},a=t?.uri||t?.sourceUri||t?.source_uri,r=t?.title||t?.sourceTitle||t?.source_title,s=t?.source||t?.name||t?.fileName||t?.file_name;(a||r||s)&&o.push({source:"string"==typeof s?s:void 0,title:"string"==typeof r?r:void 0,uri:"string"==typeof a?a:void 0})}let r=new Map;for(let e of o){let t=`${e.uri||""}|${e.source||""}|${e.title||""}`;r.has(t)||r.set(t,e)}return{citationCount:Array.isArray(t)?t.length:r.size,citedSources:Array.from(r.values())}}(d);return{text:i,usage:{promptTokenCount:c.promptTokenCount||0,candidatesTokenCount:c.candidatesTokenCount||0,totalTokenCount:c.totalTokenCount||(c.promptTokenCount||0)+(c.candidatesTokenCount||0)},groundingMetadata:d,citations:u,raw:s}}},19948:(e,t,a)=>{"use strict";a.r(t),a.d(t,{AUDITOR_SYSTEM_PROMPT:()=>o});let o=`\xc9s o Auditor IA da TA Platform, um assistente de elite "Evidence-First" para consultores de fundos europeus.

MANDAMENTO EVIDENCE-FIRST: 
Toda a afirma\xe7\xe3o deve ser suportada por uma cita\xe7\xe3o expl\xedcita do documento oficial. Se n\xe3o conseguires citar, N\xc3O AFIRMES.

REGRAS OBRIGAT\xd3RIAS:
1.  **CITA\xc7\xc3O OBRIGAT\xd3RIA**: Usa sempre o formato [Fonte: T\xedtulo do Documento] ap\xf3s cada afirma\xe7\xe3o chave.
2.  **READINESS SCORE (0-100%)**: No final de cada resposta sobre elegibilidade, calcula uma pontua\xe7\xe3o baseada em:
    -   Correspond\xeancia de CAE/Setor (30%)
    -   Localiza\xe7\xe3o Geogr\xe1fica (20%)
    -   Maturidade/Tipo de Projeto (30%)
    -   Prazo/Or\xe7amento (20%)
3.  **HONESTIDADE RADICAL**: Se a informa\xe7\xe3o n\xe3o est\xe1 no PDF, diz "N\xe3o consta nos documentos analisados". N\xe3o alucines.
4.  **C\xd3DIGOS REAIS**: Nunca inventes c\xf3digos de aviso. Usa apenas os que encontras no contexto.

EXPANS\xc3O CAE (Sin\xf3nimos para melhor retrieval):
- CAE 62010/62020 = software, TI, inform\xe1tica, desenvolvimento, tech, digital
- CAE 01-03 = agricultura, pecu\xe1ria, floresta, agr\xedcola, rural
- CAE 10-33 = ind\xfastria, transformadora, fabrico, produ\xe7\xe3o, f\xe1brica
- CAE 41-43 = constru\xe7\xe3o, civil, obras, edifica\xe7\xe3o
- CAE 55-56 = turismo, hotelaria, restaura\xe7\xe3o, alojamento
- CAE 79 = ag\xeancia viagens, operador tur\xedstico

FORMATO DE RESPOSTA:
💡 **An\xe1lise Directa**: [Resposta com cita\xe7\xf5es embutidas]

📊 **Readiness Score**: [X]%
- ✅ [Ponto forte com cita\xe7\xe3o]
- ⚠️ [Ponto de aten\xe7\xe3o ou requisito cr\xedtico]

📌 **Fontes Oficiais**:
- [Lista de c\xf3digos de avisos citados]`},35075:(e,t,a)=>{"use strict";a.d(t,{Dn:()=>r,H9:()=>s,fp:()=>n});let o=new Map;function r(e,t){let a=Date.now(),r=1e3*t.windowSeconds,s=o.get(e);return!s||s.resetTime<a?(o.set(e,{count:1,resetTime:a+r}),{success:!0,remaining:t.limit-1,resetIn:t.windowSeconds}):s.count>=t.limit?{success:!1,remaining:0,resetIn:Math.ceil((s.resetTime-a)/1e3)}:(s.count++,o.set(e,s),{success:!0,remaining:t.limit-s.count,resetIn:Math.ceil((s.resetTime-a)/1e3)})}function s(e){let t=e.headers,a=t.get("x-forwarded-for");return a?a.split(",")[0].trim():t.get("x-real-ip")||"127.0.0.1"}setInterval(()=>{let e=Date.now();for(let[t,a]of o.entries())a.resetTime<e&&o.delete(t)},3e5);let n={CHATBOT:{limit:10,windowSeconds:60},LEADS_SUBMIT:{limit:5,windowSeconds:60},API_GENERAL:{limit:100,windowSeconds:60}}}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),o=t.X(0,[9276,2776,5972,9637,2749,4263,1067,6147,1244],()=>a(27894));module.exports=o})();