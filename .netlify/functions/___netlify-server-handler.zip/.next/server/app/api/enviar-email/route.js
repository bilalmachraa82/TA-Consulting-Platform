"use strict";(()=>{var e={};e.id=3255,e.ids=[3255],e.modules={53524:e=>{e.exports=require("@prisma/client")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},6005:e=>{e.exports=require("node:crypto")},65912:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>b,patchFetch:()=>v,requestAsyncStorage:()=>m,routeModule:()=>g,serverHooks:()=>h,staticGenerationAsyncStorage:()=>f});var a={};t.r(a),t.d(a,{POST:()=>x,dynamic:()=>u});var o=t(49303),n=t(88716),i=t(60670),s=t(87070),p=t(75571),l=t(90455),d=t(2723);let u="force-dynamic",c=new d.R(process.env.RESEND_API_KEY);async function x(e){try{if(!await (0,p.getServerSession)(l.L))return s.NextResponse.json({error:"Unauthorized"},{status:401});let{destinatario:r,assunto:t,conteudo:a,tipo:o="aviso"}=await e.json();if(!r||!t||!a)return s.NextResponse.json({error:"Destinat\xe1rio, assunto e conte\xfado s\xe3o obrigat\xf3rios"},{status:400});let n=`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      line-height: 1.6;
      color: #333;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 30px auto;
      background: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }
    .header h1 {
      margin: 0;
      font-size: 24px;
      font-weight: 600;
    }
    .content {
      padding: 30px;
    }
    .content h2 {
      color: #667eea;
      font-size: 20px;
      margin-top: 0;
    }
    .content p {
      margin: 15px 0;
      color: #555;
    }
    .badge {
      display: inline-block;
      padding: 6px 12px;
      background: #f0f4ff;
      color: #667eea;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 600;
      margin: 5px 0;
    }
    .footer {
      background: #f8f9fa;
      padding: 20px;
      text-align: center;
      font-size: 12px;
      color: #888;
      border-top: 1px solid #e0e0e0;
    }
    .button {
      display: inline-block;
      padding: 12px 24px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      text-decoration: none;
      border-radius: 6px;
      margin: 15px 0;
      font-weight: 600;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🎯 TA Consulting Platform</h1>
      <p style="margin: 5px 0 0 0; opacity: 0.9;">Consultoria em Fundos Europeus</p>
    </div>
    <div class="content">
      ${a}
    </div>
    <div class="footer">
      <p><strong>TA Consulting</strong></p>
      <p>Esta \xe9 uma notifica\xe7\xe3o autom\xe1tica da plataforma TA Consulting.</p>
      <p>\xa9 ${new Date().getFullYear()} TA Consulting. Todos os direitos reservados.</p>
    </div>
  </div>
</body>
</html>
    `,i=await c.emails.send({from:"TA Consulting Platform <noreply@ta-consulting-platfo-tfdltj.abacusai.app>",to:[r],subject:t,html:n});return s.NextResponse.json({success:!0,data:i})}catch(e){return console.error("Erro ao enviar email:",e),s.NextResponse.json({error:"Erro ao enviar email",details:e.message},{status:500})}}let g=new o.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/enviar-email/route",pathname:"/api/enviar-email",filename:"route",bundlePath:"app/api/enviar-email/route"},resolvedPagePath:"/Users/bilal/Programaçao/TA consulting pltaform ai/TA-Consulting-Platform/app/api/enviar-email/route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:m,staticGenerationAsyncStorage:f,serverHooks:h}=g,b="/api/enviar-email/route";function v(){return(0,i.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:f})}},90455:(e,r,t)=>{t.d(r,{L:()=>p});var a=t(13539),o=t(53797),n=t(42023),i=t.n(n),s=t(71244);let p={adapter:(()=>{try{return(0,a.N)(s._B)}catch{return}})(),session:{strategy:"jwt"},pages:{signIn:"/auth/login"},providers:[(0,o.Z)({name:"credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;let r=await s._B.user.findUnique({where:{email:e.email}});return r&&r.password&&await i().compare(e.password,r.password)?{id:r.id,email:r.email,name:r.name,role:r.role}:null}})],callbacks:{jwt:async({token:e,user:r})=>(r&&(e.role=r.role),e),session:async({session:e,token:r})=>(r&&e.user&&(e.user.id=r.sub,e.user.role=r.role),e)}}}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[9276,2776,5972,9637,2723,1244],()=>t(65912));module.exports=a})();