"use strict";(()=>{var e={};e.id=2097,e.ids=[2097],e.modules={53524:e=>{e.exports=require("@prisma/client")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},6005:e=>{e.exports=require("node:crypto")},11582:(e,o,t)=>{t.r(o),t.d(o,{originalPathname:()=>A,patchFetch:()=>b,requestAsyncStorage:()=>f,routeModule:()=>x,serverHooks:()=>w,staticGenerationAsyncStorage:()=>y});var r={};t.r(r),t.d(r,{GET:()=>h,dynamic:()=>g,maxDuration:()=>v});var a=t(49303),s=t(88716),n=t(60670),i=t(87070),l=t(71244),c=t(18794),d=t(78525);let p=new(t(2723)).R(process.env.RESEND_API_KEY);async function u(){console.log("[Alert Service] Starting compatibility check...");let{avisos:e}=await (0,c._h)();if(0===e.length)return console.log("[Alert Service] No active avisos found."),{leadsProcessed:0,emailsSent:0,errors:0};let o=await l._B.lead.findMany({where:{alertasAtivos:!0}});console.log(`[Alert Service] Checking ${o.length} subscribed leads against ${e.length} avisos...`);let t=0,r=0;for(let a of o)try{if(a.lastAlertSentAt&&Date.now()-a.lastAlertSentAt.getTime()<864e5)continue;let o={nomeEmpresa:a.nomeEmpresa||a.nome,email:a.email,distrito:a.distrito||"",tipoProjetoDesejado:a.tipoProjeto||"",cae:a.cae||void 0,dimensao:a.dimensaoDeclarada,investimentoEstimado:a.investimentoVal||void 0,empregados:a.empregados||void 0},r=(await (0,d.VD)(o,e)).filter(e=>e.score>=70);r.length>0&&(console.log(`[Alert Service] Found ${r.length} matches for ${a.email}. Sending email...`),await m(a.email,a.nome,r),await l._B.lead.update({where:{id:a.id},data:{lastAlertSentAt:new Date}}),t++)}catch(e){console.error(`[Alert Service] Error processing lead ${a.id}:`,e),r++}return{leadsProcessed:o.length,emailsSent:t,errors:r}}async function m(e,o,t){let r=t.map(e=>`
        <div style="margin-bottom: 20px; padding: 15px; border: 1px solid #e0e0e0; border-radius: 8px;">
            <h3 style="margin: 0; color: #2563eb;">${e.avisoNome}</h3>
            <p style="margin: 5px 0; color: #64748b;">Confian\xe7a: <strong>${e.score}%</strong></p>
            <p style="margin: 5px 0;">${e.reasons.slice(0,2).join(" • ")}</p>
            <div style="margin-top: 10px;">
                <a href="${e.link||"#"}" style="color: #2563eb; text-decoration: none; font-weight: 500;">Ver Aviso Oficial &rarr;</a>
            </div>
        </div>
    `).join(""),a=`
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <h2>Novas Oportunidades Encontradas! 🎯</h2>
            <p>Ol\xe1 ${o},</p>
            <p>O nosso sistema encontrou <strong>${t.length} novos avisos</strong> de fundos compat\xedveis com o perfil da sua empresa.</p>
            
            <div style="margin: 30px 0;">
                ${r}
            </div>

            <p style="color: #64748b; font-size: 14px;">
                Para apoio na candidatura, agende uma reuni\xe3o com os nossos especialistas.
            </p>
            
            <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 30px 0;" />
            <p style="font-size: 12px; color: #94a3b8;">
                Recebeu este email porque ativou os alertas de fundos na TA Consulting.
            </p>
        </div>
    `;await p.emails.send({from:"TA Consulting <noreply@ta-consulting-platfo-tfdltj.abacusai.app>",to:e,subject:`🎯 ${t.length} Novos Fundos Compat\xedveis Encontrados!`,html:a})}let g="force-dynamic",v=60;async function h(e){try{e.headers.get("authorization");let o=await u();return i.NextResponse.json({success:!0,data:o,timestamp:new Date().toISOString()})}catch(e){return console.error("Cron job failed:",e),i.NextResponse.json({success:!1,error:"Internal Server Error"},{status:500})}}let x=new a.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/cron/check-new-avisos/route",pathname:"/api/cron/check-new-avisos",filename:"route",bundlePath:"app/api/cron/check-new-avisos/route"},resolvedPagePath:"/Users/bilal/Programaçao/TA consulting pltaform ai/TA-Consulting-Platform/app/api/cron/check-new-avisos/route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:f,staticGenerationAsyncStorage:y,serverHooks:w}=x,A="/api/cron/check-new-avisos/route";function b(){return(0,n.patchFetch)({serverHooks:w,staticGenerationAsyncStorage:y})}}};var o=require("../../../../webpack-runtime.js");o.C(e);var t=e=>o(o.s=e),r=o.X(0,[9276,5972,2723,1244,2082],()=>t(11582));module.exports=r})();