"use strict";(()=>{var e={};e.id=1362,e.ids=[1362],e.modules={53524:e=>{e.exports=require("@prisma/client")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},15641:(e,o,a)=>{a.r(o),a.d(o,{originalPathname:()=>C,patchFetch:()=>P,requestAsyncStorage:()=>I,routeModule:()=>v,serverHooks:()=>f,staticGenerationAsyncStorage:()=>h});var t={};a.r(t),a.d(t,{POST:()=>A});var r=a(49303),i=a(88716),s=a(60670),n=a(87070),d=a(75571),c=a(90455),l=a(11258),m=a(71244),p=a(78525);let u=`\xc9s um avaliador rigoroso de candidaturas a fundos europeus em Portugal.
O teu objetivo \xe9 ser MUITO EXIGENTE e identificar TODOS os pontos fracos de uma candidatura ANTES de ser submetida.

PERSONA: Imagina que \xe9s o avaliador mais estrito do painel. Se houver uma raz\xe3o para rejeitar, tu encontras.

OUTPUTS ESPERADOS (JSON):
{
  "approvalProbability": 0-100,
  "overallVerdict": "FORTE" | "VI\xc1VEL" | "FRACO" | "N\xc3O_CANDIDATAR",
  "risks": [
    {
      "category": "ELIGIBILITY" | "COMPETITIVENESS" | "DOCUMENTATION" | "TIMING",
      "severity": "CRITICO" | "ALTO" | "MEDIO" | "BAIXO",
      "description": "...",
      "mitigation": "..."
    }
  ],
  "recommendations": ["..."],
  "missingDocuments": ["..."],
  "estimatedPrepTime": "X-Y semanas",
  "reasoning": "Resumo da an\xe1lise em 2-3 frases"
}

REGRAS DE AVALIA\xc7\xc3O:
1. ELEGIBILIDADE (40%): CAE, dimens\xe3o, regi\xe3o, requisitos obrigat\xf3rios
2. COMPETITIVIDADE (30%): Diferencia\xe7\xe3o, inova\xe7\xe3o, impacto
3. DOCUMENTA\xc7\xc3O (20%): Completude do dossi\xea, validade de certid\xf5es
4. TIMING (10%): Prazo dispon\xedvel vs. complexidade

SEVERIDADE:
- CRITICO: Candidatura ser\xe1 rejeitada automaticamente
- ALTO: Forte probabilidade de rejei\xe7\xe3o
- MEDIO: Pode baixar pontua\xe7\xe3o significativamente
- BAIXO: Melhoria recomendada mas n\xe3o cr\xedtica`;async function x(e){let o=await m._B.empresa.findUnique({where:{id:e},include:{documentos:!0}});if(!o)throw Error(`Empresa n\xe3o encontrada: ${e}`);return o}async function g(e){let o=await m._B.aviso.findUnique({where:{id:e},include:{chunks:{take:5,orderBy:{createdAt:"desc"}}}});if(!o)throw Error(`Aviso n\xe3o encontrado: ${e}`);return o}async function E(e){let o;let{empresaId:a,avisoId:t,projetoProposto:r}=e,i=await x(a),s=await g(t),n={nomeEmpresa:i.nome,email:i.email,distrito:i.distrito||"Lisboa",tipoProjetoDesejado:"inovacao",cae:i.cae,dimensao:i.dimensao},d={id:s.id,nome:s.nome,portal:s.portal,programa:s.programa,dataFimSubmissao:new Date(s.dataFimSubmissao),link:s.link,taxa:s.taxa,criterios:{dimensao:s.dimensaoEmpresa||[],regioes:s.regiao?[s.regiao]:[],caePrefixos:s.setoresElegiveis||[]},documentosNecessarios:["Certid\xe3o AT","Certid\xe3o SS","Certificado PME"]},c=(0,p.jC)(n,d),m=c.score,E=function(e){let o=[];for(let a of[{tipo:"CERTIDAO_AT",nome:"Certid\xe3o de n\xe3o d\xedvida \xe0s Finan\xe7as"},{tipo:"CERTIDAO_SS",nome:"Certid\xe3o de n\xe3o d\xedvida \xe0 Seguran\xe7a Social"},{tipo:"CERTIFICADO_PME",nome:"Certificado PME (se aplic\xe1vel)"}]){let t=e.find(e=>e.tipoDocumento===a.tipo);t?("EXPIRADO"===t.statusValidade||"A_EXPIRAR"===t.statusValidade)&&o.push(`${a.nome} (expirado/a expirar)`):o.push(a.nome)}return o}(i.documentos),A=function(e){let o=new Date;return Math.ceil((e.getTime()-o.getTime())/864e5)}(new Date(s.dataFimSubmissao)),v=`
## EMPRESA
- Nome: ${i.nome}
- CAE: ${i.cae||"N/A"}
- Dimens\xe3o: ${i.dimensao}
- Regi\xe3o: ${i.regiao||i.distrito||"N/A"}
- Documentos em falta: ${E.length>0?E.join(", "):"Nenhum"}

## AVISO
- Nome: ${s.nome}
- Portal: ${s.portal}
- Programa: ${s.programa}
- Taxa de financiamento: ${s.taxa||"N/A"}
- Prazo: ${A} dias restantes
- Requisitos do aviso (RAG): ${s.chunks?.length>0?s.chunks.map(e=>e.content).join("\n").slice(0,2e3):s.descricao||"Informa\xe7\xe3o n\xe3o dispon\xedvel - consultar portal original"}

## ELEGIBILIDADE DETERMIN\xcdSTICA
- Score: ${m}/100
- Match Dimens\xe3o: ${c.matchDetails.dimensaoMatch?"SIM":"N\xc3O"}
- Match Regi\xe3o: ${c.matchDetails.regiaoMatch?"SIM":"N\xc3O"}
- Match CAE: ${c.matchDetails.caeMatch?"SIM":"N\xc3O/N\xe3o confirmado"}
- Raz\xf5es: ${c.reasons.join(", ")}
- Em falta: ${c.missing.join(", ")}

## PROJETO PROPOSTO
${r||"N\xe3o especificado - avaliar apenas elegibilidade geral"}

Responde APENAS com JSON v\xe1lido.`,I=process.env.GEMINI_API_KEY;if(!I)throw Error("GEMINI_API_KEY n\xe3o configurada");let h=new l.$D(I).getGenerativeModel({model:"gemini-2.0-flash",generationConfig:{responseMimeType:"application/json"}}),f=(await h.generateContent([{text:u},{text:v}])).response.text();try{o=JSON.parse(f)}catch(e){console.error("Failed to parse AI response:",f),o={approvalProbability:m,overallVerdict:m>=70?"VI\xc1VEL":"FRACO",risks:[],recommendations:["Erro ao processar an\xe1lise AI - revisar manualmente"],reasoning:"Fallback para score de elegibilidade"}}return{approvalProbability:o.approvalProbability??m,overallVerdict:o.overallVerdict??"VI\xc1VEL",eligibilityScore:m,risks:o.risks??[],recommendations:o.recommendations??[],missingDocuments:E,estimatedPrepTime:o.estimatedPrepTime??`${Math.ceil(A/7)} semanas`,reasoning:o.reasoning??""}}async function A(e){try{let o=await (0,d.getServerSession)(c.L);if(!o?.user?.email)return n.NextResponse.json({error:"Autentica\xe7\xe3o necess\xe1ria"},{status:401});let{empresaId:a,avisoId:t,projetoProposto:r}=await e.json();if(!a||!t)return n.NextResponse.json({error:"empresaId e avisoId s\xe3o obrigat\xf3rios"},{status:400});let i=await E({empresaId:a,avisoId:t,projetoProposto:r});return n.NextResponse.json({success:!0,verdict:i,timestamp:new Date().toISOString()})}catch(e){return console.error("Critic API error:",e),n.NextResponse.json({error:e.message||"Erro ao executar an\xe1lise"},{status:500})}}let v=new r.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/critic/route",pathname:"/api/critic",filename:"route",bundlePath:"app/api/critic/route"},resolvedPagePath:"/Users/bilal/Programaçao/TA consulting pltaform ai/TA-Consulting-Platform/app/api/critic/route.ts",nextConfigOutput:"standalone",userland:t}),{requestAsyncStorage:I,staticGenerationAsyncStorage:h,serverHooks:f}=v,C="/api/critic/route";function P(){return(0,s.patchFetch)({serverHooks:f,staticGenerationAsyncStorage:h})}},90455:(e,o,a)=>{a.d(o,{L:()=>d});var t=a(13539),r=a(53797),i=a(42023),s=a.n(i),n=a(71244);let d={adapter:(()=>{try{return(0,t.N)(n._B)}catch{return}})(),session:{strategy:"jwt"},pages:{signIn:"/auth/login"},providers:[(0,r.Z)({name:"credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;let o=await n._B.user.findUnique({where:{email:e.email}});return o&&o.password&&await s().compare(e.password,o.password)?{id:o.id,email:o.email,name:o.name,role:o.role}:null}})],callbacks:{jwt:async({token:e,user:o})=>(o&&(e.role=o.role),e),session:async({session:e,token:o})=>(o&&e.user&&(e.user.id=o.sub,e.user.role=o.role),e)}}},78525:(e,o,a)=>{a.d(o,{VD:()=>i,jC:()=>r});let t={Aveiro:"Centro",Beja:"Alentejo",Braga:"Norte",Bragança:"Norte","Castelo Branco":"Centro",Coimbra:"Centro",Évora:"Alentejo",Faro:"Algarve",Guarda:"Centro",Leiria:"Centro",Lisboa:"Lisboa",Portalegre:"Alentejo",Porto:"Norte",Santarém:"Centro",Setúbal:"Lisboa","Viana do Castelo":"Norte","Vila Real":"Norte",Viseu:"Centro",Açores:"A\xe7ores",Madeira:"Madeira"};function r(e,o){var a,r,i,s,n,d,c,l,m;let p=new Date,u=Math.ceil((o.dataFimSubmissao.getTime()-p.getTime())/864e5),x=o.criterios,g=(a=e.dimensao,r=x.dimensao,!a||!r||0===r.length||r.some(e=>e.toUpperCase()===a.toUpperCase())),E=function(e,o){if(!o||0===o.length)return!0;let a=t[e];return!!a&&o.some(e=>e.toLowerCase()===a.toLowerCase()||"nacional"===e.toLowerCase()||"todo o pa\xeds"===e.toLowerCase())}(e.distrito,x.regioes),A=(i=e.cae,s=x.caePrefixos,!!i&&!!s&&0!==s.length&&s.some(e=>i.startsWith(e))),v=(n=e.tipoProjetoDesejado,!(d=x.tiposProjeto)||0===d.length||d.some(e=>e.toLowerCase()===n.toLowerCase())),I=(c=e.investimentoEstimado,l=x.investimentoMin,m=x.investimentoMax,!c||(!l||!(c<l))&&(!m||!(c>m))),h=[];E&&x.regioes&&x.regioes.length>0?h.push(`Regi\xe3o compat\xedvel: ${t[e.distrito]||e.distrito}`):E&&h.push("\xc2mbito Nacional"),g&&e.dimensao&&h.push(`Dimens\xe3o eleg\xedvel: ${e.dimensao}`),A&&e.cae&&h.push(`CAE compat\xedvel: ${e.cae}`),v&&h.push("Tipo de projeto alinhado"),I&&e.investimentoEstimado&&h.push("Investimento dentro dos limites");let f=[];e.dimensao||f.push("Confirmar dimens\xe3o da empresa (n\xba empregados)"),e.cae||f.push("Confirmar CAE principal"),!e.investimentoEstimado&&(x.investimentoMin||x.investimentoMax)&&f.push("Indicar montante de investimento previsto"),o.documentosNecessarios&&o.documentosNecessarios.length>0&&f.push(`Documenta\xe7\xe3o: ${o.documentosNecessarios.slice(0,2).join(", ")}`),!A&&e.cae&&f.push("CAE pode n\xe3o ser eleg\xedvel - confirmar com regulamento");let C=0,P={regiao:25,dimensao:25,cae:20,tipoProjeto:15,investimento:15};E&&(C+=P.regiao),g&&(C+=P.dimensao),A&&(C+=P.cae),v&&(C+=P.tipoProjeto),I&&(C+=P.investimento);let O="BAIXA";return e.cae&&e.dimensao&&e.investimentoEstimado?O="ALTA":(e.cae||e.dimensao)&&(O="MEDIA"),{avisoId:o.id,avisoNome:o.nome,portal:o.portal,link:o.link,taxa:o.taxa,diasRestantes:u,score:C,confidence:O,reasons:h,missing:f,matchDetails:{dimensaoMatch:g,regiaoMatch:E,caeMatch:A,tipoProjetoMatch:v,investimentoMatch:I}}}async function i(e,o){let a=[];for(let t of o){if(t.dataFimSubmissao<new Date)continue;let o=r(e,t);o.score>=40&&a.push(o)}return a.sort((e,o)=>o.score-e.score),a}}};var o=require("../../../webpack-runtime.js");o.C(e);var a=e=>o(o.s=e),t=o.X(0,[9276,2776,5972,9637,1258,1244],()=>a(15641));module.exports=t})();